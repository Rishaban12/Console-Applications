package com.employee.empTrack.features.store;

public interface IStoreModelController {
    abstract void sentBack();
}
