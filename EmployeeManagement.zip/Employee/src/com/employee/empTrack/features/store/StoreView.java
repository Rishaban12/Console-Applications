package com.employee.empTrack.features.store;

import com.employee.empTrack.dto.EmployeeInfo;

import java.util.Scanner;

public class StoreView implements IControllerStoreView{
   private final IStoreViewController storeController;
   private final Scanner sc=new Scanner(System.in);

   public StoreView(){
       storeController=new StoreController(this);
   }
    public void addEmployee(){
        String empName="";
        int empId=0;
        String emailId="";
        String contactNo="";
        String role="";

        while(true){
            try {
                System.out.println("Enter the Employee id(int): ");
                empId = sc.nextInt();
                sc.nextLine();
                System.out.println("Enter the Employee Name: ");
                empName = sc.nextLine();
                System.out.println("Enter the valid EmailId: ");
                emailId = sc.nextLine();
                System.out.println("Enter the contactNo: ");
                contactNo = sc.nextLine();
                System.out.println("Enter the role: ");
                role = sc.nextLine();
                if(!((empId>='a' && empId<='z') || (empId>='A' && empId<='Z')) && !empName.matches("^[A-Za-z0-9+_.-]+@(.+)$")){
                    break;
                }
            } catch (Exception e) {
                System.out.println("Please provide the valid option");
                sc.nextLine();
            }
        }
        EmployeeInfo employeeInfo=new EmployeeInfo(empId,empName,emailId,contactNo,role);
        storeController.addBack(employeeInfo);
    }

    @Override
    public void sentBack() {
        System.out.println("Added Successfully!!");
    }
}
