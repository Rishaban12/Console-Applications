package com.employee.empTrack.features.store;

import com.employee.empTrack.dto.EmployeeInfo;

public interface IStoreViewController {
   abstract void addBack(EmployeeInfo employeeInfo);
}
