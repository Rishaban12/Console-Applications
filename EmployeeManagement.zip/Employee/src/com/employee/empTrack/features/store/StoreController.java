package com.employee.empTrack.features.store;

import com.employee.empTrack.dto.EmployeeInfo;

public class StoreController implements IStoreViewController,IStoreModelController{
    private final IControllerStoreView storeView;
    private final IControllerStoreModel storeModel;

    public StoreController(StoreView storeView){
        this.storeView=storeView;
        storeModel =new StoreModel(this);
    }

    @Override
    public void addBack(EmployeeInfo employeeInfo) {
           storeModel.addBack(employeeInfo);
    }

    @Override
    public void sentBack() {
         storeView.sentBack();
    }
}
