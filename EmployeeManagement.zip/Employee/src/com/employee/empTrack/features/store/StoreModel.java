package com.employee.empTrack.features.store;

import com.employee.empTrack.dto.EmployeeInfo;
import com.employee.empTrack.repository.EmpTrackDb;

public class StoreModel implements IControllerStoreModel{
    private final IStoreModelController storeController;

    public StoreModel(StoreController storeController){
        this.storeController=storeController;
    }

    @Override
    public void addBack(EmployeeInfo employeeInfo){
        EmpTrackDb.getInstance().addBack(employeeInfo);
        storeController.sentBack();
    }
}
