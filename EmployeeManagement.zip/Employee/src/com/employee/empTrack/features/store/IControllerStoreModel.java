package com.employee.empTrack.features.store;

import com.employee.empTrack.dto.EmployeeInfo;

public interface IControllerStoreModel {
    abstract void addBack(EmployeeInfo employeeInfo);
}
