package com.employee.empTrack.features.store;

public interface IControllerStoreView {
    abstract void sentBack();
}
