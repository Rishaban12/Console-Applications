package com.employee.empTrack.features.update;

import com.employee.empTrack.dto.EmployeeInfo;

public interface IControllerEditModel {
    abstract EmployeeInfo edit(int id);
}
