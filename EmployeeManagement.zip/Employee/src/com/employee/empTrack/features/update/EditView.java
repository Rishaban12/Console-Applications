package com.employee.empTrack.features.update;

import com.employee.empTrack.dto.EmployeeInfo;
import com.employee.empTrack.features.dashboard.DashboardView;

import java.util.Scanner;

public class EditView implements IControllerEditView{
    private final IEditViewController editController;
    private final DashboardView dashboardView;
    private final Scanner sc=new Scanner(System.in);
    public EditView(DashboardView dashboardView1){
        this.dashboardView = dashboardView1;
        editController=new EditController(this);
    }

    public void updateEmployee(){
        dashboardView.viewEmployee();
        int id=0;
        while(true){
            System.out.println("Which Employee do you want to edit?: ");
            System.out.println("Enter their Employee ID: ");
            try {
                id = sc.nextInt();
                if (!((id >= 'a' && id <= 'z') || (id >= 'A' && id <= 'Z'))) {
                    break;
                }
            } catch (Exception e) {
                System.out.println("Please provide the valid Id");
            }
        }
        EmployeeInfo info= editController.edit(id);
        if(info==null){
            System.out.println("Employee is not found");
            return;
        }
        editStart(info);
    }

    public void editStart(EmployeeInfo emp){
        System.out.println("=====Edit the employee=====");
        System.out.println("------------------------");
        System.out.println("Employee Id: "+emp.getId()+"\n"+"Employee Name: "+emp.getEmpName()+"\n"+
                "Employee EmailId: "+emp.getEmailId()+"\n"+"Employee ContactNo: "+emp.getContactNo()+"\n"+
                "Employee role: "+emp.getRole());
        System.out.println("------------------------");
        boolean flag=true;
        while(flag) {
            print();
            System.out.println("Now what do you want to edit?...Enter the option(1-6): ");
            int opt=sc.nextInt();
            switch (opt){
                case 1:
                    System.out.println("Enter the new Name: ");
                    String name=sc.next();
                    emp.setEmpName(name);
                    break;
                case 2:
                    System.out.println("Enter the new EmailId ");
                    String email=sc.next();
                    emp.setEmailId(email);
                    break;
                case 3:
                    System.out.println("Enter the new ContactNo: ");
                    String contact=sc.next();
                    emp.setContactNo(contact);
                    break;
                case 4:
                    System.out.println("Enter the new Role: ");
                    String role=sc.next();
                    emp.setRole(role);
                    break;
                case 5:
                    flag=false;
                    break;
                default:
                    System.out.println("Please provide the valid option");
            }
        }
        System.out.println("Employee details was edited...");
        dashboardView.viewEmployee();
    }

    public void print(){
        System.out.println("1. Employee Name");
        System.out.println("2. Employee Email");
        System.out.println("3. Employee ContactNo");
        System.out.println("4. Employee role");
        System.out.println("5. No Changes");
    }

}
