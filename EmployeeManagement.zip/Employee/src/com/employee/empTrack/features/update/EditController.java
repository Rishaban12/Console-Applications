package com.employee.empTrack.features.update;

import com.employee.empTrack.dto.EmployeeInfo;

public class EditController implements IEditViewController,IEditModelController{
    private final IControllerEditView editView;
    private final IControllerEditModel editModel;

    public EditController(EditView editView){
        this.editView=editView;
        editModel=new EditModel(this);
    }

    @Override
    public EmployeeInfo edit(int id) {
        return editModel.edit(id);
    }
}
