package com.employee.empTrack.features.update;

import com.employee.empTrack.dto.EmployeeInfo;
import com.employee.empTrack.repository.EmpTrackDb;

public class EditModel implements IControllerEditModel{
    private final IEditModelController editController;

    public EditModel(EditController editController){
        this.editController=editController;
    }
    public EmployeeInfo edit(int id) {
        return EmpTrackDb.getInstance().edit(id);
    }
}
