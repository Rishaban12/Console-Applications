package com.employee.empTrack.features.update;

public interface IControllerEditView {
}
