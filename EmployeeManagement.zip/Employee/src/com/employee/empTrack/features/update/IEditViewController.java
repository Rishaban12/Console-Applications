package com.employee.empTrack.features.update;

import com.employee.empTrack.dto.EmployeeInfo;

public interface IEditViewController {
     abstract EmployeeInfo edit(int id);
}
