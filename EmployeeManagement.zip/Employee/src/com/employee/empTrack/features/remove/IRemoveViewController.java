package com.employee.empTrack.features.remove;

public interface IRemoveViewController {
    abstract void remove(int opt) ;
}
