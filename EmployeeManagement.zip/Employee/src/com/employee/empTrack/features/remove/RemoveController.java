package com.employee.empTrack.features.remove;

public class RemoveController implements IRemoveViewController,IRemoveModelController{
    private final IControllerRemoveView removeView;
    private final IControllerRemoveModel removeModel;

    public RemoveController(RemoveView removeView){
        this.removeView=removeView;
        removeModel=new RemoveModel(this);
    }

    public void remove(int opt) {
        removeModel.remove(opt);
    }

    @Override
    public void removeStatus() {
        removeView.removeStatus();
    }
}
