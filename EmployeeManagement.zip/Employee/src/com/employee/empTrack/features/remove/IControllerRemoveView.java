package com.employee.empTrack.features.remove;

public interface IControllerRemoveView {
   abstract void removeStatus();
}
