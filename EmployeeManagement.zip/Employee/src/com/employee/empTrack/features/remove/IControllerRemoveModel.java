package com.employee.empTrack.features.remove;

public interface IControllerRemoveModel {
    abstract void remove(int opt);
}
