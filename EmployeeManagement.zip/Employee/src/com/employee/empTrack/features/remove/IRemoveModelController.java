package com.employee.empTrack.features.remove;

public interface IRemoveModelController {
    abstract void removeStatus();
}
