package com.employee.empTrack.features.remove;

import com.employee.empTrack.repository.EmpTrackDb;

public class RemoveModel implements IControllerRemoveModel{
    private final IRemoveModelController removeController;

    public RemoveModel(RemoveController removeController){
        this.removeController=removeController;
    }
    public void remove(int id) {
        EmpTrackDb.getInstance().remove(id);
        removeController.removeStatus();
    }
}
