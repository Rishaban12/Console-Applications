package com.employee.empTrack.features.remove;

import com.employee.empTrack.features.dashboard.DashboardView;

import java.util.Scanner;

public class RemoveView implements IControllerRemoveView{
    private final IRemoveViewController removeController;
    private final DashboardView dashboardView;
    private Scanner sc=new Scanner(System.in);

    public RemoveView(DashboardView dashboardView){
        this.dashboardView=dashboardView;
        this.removeController=new RemoveController(this);
    }

    public void removeEmployee(){
        dashboardView.viewEmployee();

        int opt=0;
        while(true) {
            System.out.println("Enter the Remove Employee Id: ");

            try {
                opt = sc.nextInt();
                if(!((opt>='a' && opt<='z') || (opt>='A' && opt<='Z'))){
                    break;
                }
            }catch (Exception e){
                System.out.println("Please provide the valid option");
            }
        }
        removeController.remove(opt);
    }

    @Override
    public void removeStatus() {
        System.out.println("Successfully removed the Employee");
        dashboardView.viewEmployee();
    }
}
