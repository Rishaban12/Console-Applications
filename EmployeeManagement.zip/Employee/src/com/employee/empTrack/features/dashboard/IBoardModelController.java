package com.employee.empTrack.features.dashboard;

public interface IBoardModelController {

}
