package com.employee.empTrack.features.dashboard;

import com.employee.empTrack.dto.EmployeeInfo;

import java.util.Collections;
import java.util.List;

public class DashBoardController implements IBoardViewController,IBoardModelController{
    private final IControllerBoardView dashBoardView;
    private final IControllerBoardModel dashBoardModel;

    public DashBoardController(DashboardView dashboardView){
        this.dashBoardView=dashboardView;
        dashBoardModel=new DashBoardModel(this);
    }


    @Override
    public List<EmployeeInfo> getEmp() {
       return dashBoardModel.getEmp();
    }


}
