package com.employee.empTrack.features.dashboard;

import com.employee.empTrack.dto.EmployeeInfo;
import com.employee.empTrack.repository.EmpTrackDb;

import java.util.Collections;
import java.util.List;

public class DashBoardModel implements IControllerBoardModel{
    private final IBoardModelController dashBoardController;

    public DashBoardModel(DashBoardController dashBoardController){
        this.dashBoardController=dashBoardController;
    }


    @Override
    public List<EmployeeInfo> getEmp() {
        return EmpTrackDb.getInstance().getEmp();
    }

}
