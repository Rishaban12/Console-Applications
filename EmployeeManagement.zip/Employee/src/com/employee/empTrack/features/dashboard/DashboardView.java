package com.employee.empTrack.features.dashboard;

import com.employee.empTrack.dto.EmployeeInfo;
import com.employee.empTrack.features.login.LoginView;
import com.employee.empTrack.features.remove.RemoveView;
import com.employee.empTrack.features.store.StoreView;
import com.employee.empTrack.features.update.EditView;

import java.util.List;
import java.util.Scanner;

public class DashboardView implements IControllerBoardView {
    private final IBoardViewController dashBoardController;
    private final Scanner sc=new Scanner(System.in);
    private final EditView editView;
    private final RemoveView removeView;
    public DashboardView(){
       editView=new EditView(this);
       removeView=new RemoveView(this);
        dashBoardController=new DashBoardController(this);
    }

    public void showDashBoard() {
        boolean flag=true;
        while(flag) {
            printMenu();
            String option = sc.next();

            switch (option) {
                case "1":
                    new StoreView().addEmployee();
                    break;
                case "2":
                    viewEmployee();
                    break;
                case "3":
                    editView.updateEmployee();
                    break;
                case "4":
                    removeView.removeEmployee();
                    break;
                case "5":
                    System.out.println("You are Logging out...");
                    flag = false;
                    break;
                default:
                    System.out.println("Please provide the valid option");
            }
        }
            System.out.println("Do you want login again (Y/N): ");
            String opt=sc.next();
            if(opt.equals("y") || opt.equals("Y")){
                new LoginView().initLogin();
            }else{
                System.out.println("Thank you for using the EmpTrack app");
            }
    }

    public void printMenu(){
        System.out.println("========DashBoard========");
        System.out.println("1. Store the Employee Details");
        System.out.println("2. View the Employee Details");
        System.out.println("3. Update the Employee Details");
        System.out.println("4. Remove the Employee");
        System.out.println("5. Logout");
        System.out.println("Choose the option (1-5)");
    }

    public void viewEmployee(){
       List<EmployeeInfo> list= dashBoardController.getEmp();
       if(list.isEmpty()) {
           System.out.println("!!!!Employee Table is Empty!!!!");
       }
       System.out.println("============Employee Table=============");
       for(EmployeeInfo emp: list){
           System.out.println("------------------------");
           System.out.println("Employee Id: "+emp.getId()+"\n"+"Employee Name: "+emp.getEmpName()+"\n"+
                   "Employee EmailId: "+emp.getEmailId()+"\n"+"Employee ContactNo: "+emp.getContactNo()+"\n"+
                   "Employee role: "+emp.getRole());
           System.out.println("------------------------");
       }
        System.out.println("=======================================");
    }
}
