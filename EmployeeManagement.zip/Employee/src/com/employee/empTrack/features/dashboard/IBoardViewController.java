package com.employee.empTrack.features.dashboard;

import com.employee.empTrack.dto.EmployeeInfo;

import java.util.List;

public interface IBoardViewController {

    abstract List<EmployeeInfo> getEmp();

}
