package com.employee.empTrack.features.login;

public interface ILoginViewController {
    abstract void validateCredentials(String userName,int password);
}
