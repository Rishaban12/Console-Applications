package com.employee.empTrack.features.login;

import com.employee.empTrack.repository.EmpTrackDb;

public class LoginModel implements IControllerLoginModel{
    private final ILoginModelController loginController;

    public LoginModel(LoginController loginController){
        this.loginController= loginController;
    }

    @Override
    public void validateCredentials(String userName, int password) {
        boolean val= EmpTrackDb.getInstance().validateCredentials(userName,password);
        if(val){
            loginController.onLoginSuccess();
        }else{
            loginController.onLoginFailed();
        }
    }
}
