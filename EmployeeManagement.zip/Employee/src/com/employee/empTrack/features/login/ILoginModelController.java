package com.employee.empTrack.features.login;

public interface ILoginModelController {
     abstract void onLoginSuccess();
     abstract void onLoginFailed();
}
