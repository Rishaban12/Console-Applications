package com.employee.empTrack.features.login;

import com.employee.empTrack.features.dashboard.DashboardView;

import java.util.Scanner;

public class LoginView implements IControllerLoginView{
    private final ILoginViewController loginController;
    private final Scanner sc=new Scanner(System.in);

    public LoginView(){
        loginController=new LoginController(this);
    }

    public void initLogin() {
             String userName="";
             int password=0;
          while(true){
              try {
                  System.out.println("Enter the userName: ");
                  userName = sc.nextLine().trim();
                  System.out.println("Enter the password(int): ");
                  password = Integer.parseInt(sc.nextLine());
                  if (!((password >= 'a' && password <= 'z') || (password >= 'A' && password <= 'Z'))) {
                      break;
                  }
              }catch (Exception e){
                  System.out.println("Username or password is invalid");
              }
          }
          loginController.validateCredentials(userName,password);
    }

    @Override
    public void onLoginSuccess() {
        System.out.println("Successfully Login!!!");
        DashboardView dashboardView=new DashboardView();
        dashboardView.showDashBoard();
    }

    public void onLoginFailed(){
        System.out.println("Login Failed!!");
        initLogin();
    }
}
