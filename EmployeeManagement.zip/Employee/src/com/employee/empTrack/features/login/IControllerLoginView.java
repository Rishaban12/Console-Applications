package com.employee.empTrack.features.login;

public interface IControllerLoginView {

    abstract void onLoginSuccess();
    abstract void onLoginFailed();
}
