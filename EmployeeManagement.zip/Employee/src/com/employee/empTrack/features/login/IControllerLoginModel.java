package com.employee.empTrack.features.login;

public interface IControllerLoginModel {
    abstract void validateCredentials(String userName,int password);
}
