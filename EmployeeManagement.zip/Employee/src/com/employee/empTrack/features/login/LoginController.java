package com.employee.empTrack.features.login;

public class LoginController implements ILoginViewController,ILoginModelController {

    private final IControllerLoginView loginView;
    private final IControllerLoginModel loginModel;

    public LoginController(LoginView loginView){
        this.loginView=loginView;
        loginModel=new LoginModel(this);
    }

    @Override
    public void validateCredentials(String userName, int password) {
          loginModel.validateCredentials(userName,password);
    }
    public void onLoginSuccess(){
        loginView.onLoginSuccess();
    }
    public void onLoginFailed(){
        loginView.onLoginFailed();
    }

}
