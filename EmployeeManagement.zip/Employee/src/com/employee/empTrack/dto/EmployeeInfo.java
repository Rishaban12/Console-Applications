package com.employee.empTrack.dto;

public class EmployeeInfo {
    private int id;
    private String empName;
    private String emailId;
    private String contactNo;
    private String role;

    public EmployeeInfo(int id, String empName, String emailId, String contactNo, String role){
        this.id=id;
        this.empName=empName;
        this.emailId=emailId;
        this.contactNo=contactNo;
        this.role=role;
    }

    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return id;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
