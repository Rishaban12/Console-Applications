package com.employee.empTrack.repository;

import com.employee.empTrack.dto.EmployeeInfo;
import com.employee.empTrack.dto.LoginCredentials;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EmpTrackDb {
    private static EmpTrackDb s=null;
    private final LoginCredentials loginCredentials=new LoginCredentials(1,"admin",123098);
    private static final List<EmployeeInfo> empAdd=new ArrayList<>();

    private EmpTrackDb(){};

    public static EmpTrackDb getInstance(){
        if(s==null){
            s=new EmpTrackDb();
        }
        return s;
    }

    public boolean validateCredentials(String userName,int password){
        if(userName.equals(loginCredentials.getUsername()) && password==loginCredentials.getPassword()){
            return true;
        }
        return false;
    }

    public void addBack(EmployeeInfo employeeInfo){
        empAdd.add(employeeInfo);
    }

    public List<EmployeeInfo> getEmp(){
        return empAdd;
    }

    public void remove(int id){
        Iterator<EmployeeInfo> it=empAdd.iterator();

        while(it.hasNext()){
            EmployeeInfo employeeInfo=it.next();
            if(employeeInfo.getId()==id){
                it.remove();
                return;
            }
        }
    }

    public EmployeeInfo edit(int id){
        for(EmployeeInfo employeeInfo: empAdd){
            if(employeeInfo.getId()==id){
               return employeeInfo;
            }
        }
        return null;
    }
}
