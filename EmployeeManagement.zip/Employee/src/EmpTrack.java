import com.employee.empTrack.features.login.LoginView;

public class EmpTrack {
    public static final String version="0.0.1";

    public static void main(String[] args) {
        EmpTrack empTrack=new EmpTrack();
        empTrack.init();
    }
    private void init(){
        System.out.println("Welcome to the EmpTrack app "+version);
        LoginView loginView=new LoginView();
        loginView.initLogin();
    }
}
