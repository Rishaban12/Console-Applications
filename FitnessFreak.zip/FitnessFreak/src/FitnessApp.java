import com.fit.fitnessfreak.features.dashboard.DashBoardView;

public class FitnessApp {
    public static final String version="0.0.1";

    public static void main(String[] args) {
        FitnessApp fitnessApp=new FitnessApp();
        fitnessApp.init();
    }
    public void init(){
        System.out.println("Welcome to our Fitness App "+version);
        new DashBoardView().initView();
        System.out.println("Thank you visiting out App1");
    }
}
