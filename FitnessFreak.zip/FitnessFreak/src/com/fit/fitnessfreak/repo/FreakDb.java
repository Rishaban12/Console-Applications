package com.fit.fitnessfreak.repo;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.time.LocalDate;
import java.util.*;

public class FreakDb {
    private static FreakDb s=null;
    private static final List<User> addUser=new ArrayList<>();
    private static final Map<User,List<Exercise>> addWork=new HashMap<>();

    private FreakDb(){};

    public static FreakDb getInstance(){
        if(s==null){
            s=new FreakDb();
        }
        return s;
    }

    public void add(int id, String name, int age, String level) {
        User user=new User(id,name,age,level);
        addUser.add(user);
    }

    public List<User> viewUser() {
        return addUser;
    }

    public boolean addWork(int id, int exeId, LocalDate date, String name, int reps, int set) {
        for(User use: addUser){
            if(use.getFreakId()==id){

                List<Exercise> adds=new ArrayList<>();
                adds.add(new Exercise(id, exeId, date, name, set, reps));

               if(addWork.containsKey(use)){
                   addWork.get(use).addAll(adds);
               }else {
                   addWork.put(use,adds);
               }
                return true;
            }
        }
        return false;
    }
    public Map<User,List<Exercise>> viewWork(){
        return addWork;
    }


    public Map<User,List<Exercise>> getDeletePerson(int id){
        Map<User,List<Exercise>> map=new HashMap<>();
        for(User use: addUser){
            if(use.getFreakId()==id && addWork.containsKey(use)){
                map.put(use,addWork.get(use));
            }
        }
        return map;
    }

    public void deleteAll(int id) {
        Iterator<Map.Entry<User, List<Exercise>>> it = addWork.entrySet().iterator();

        while(it.hasNext()) {
            Map.Entry<User, List<Exercise>> entry = it.next();
            if(entry.getKey().getFreakId() == id) {
                it.remove();
            }
        }
    }

    public void ExDelete(int id,int exeId) {
        for (User use : addUser) {
            if (use.getFreakId() == id) {
                List<Exercise> list = addWork.get(use);
                if (list != null) {
                    list.removeIf(e -> e.getExerciseId() == exeId);
                }
                break;
            }
        }
    }

    public boolean check(int id) {
        for(User use: addUser){
            if(use.getFreakId()==id) return true;
        }
        return false;
    }

    public Map<User, List<Exercise>> viewById(int id) {
        Map<User,List<Exercise>> map=new HashMap<>();

        for(User use: addUser){
            if(use.getFreakId()==id && addWork.containsKey(use)){
                map.put(use,addWork.get(use));
            }
        }
        return map;
    }

    public void changeSet(int exeId, int id, int set) {
        User target = null;
        for (User u : addWork.keySet()) {
            if (u.getFreakId() == id) {
                target = u;
                break;
            }
        }
        if (target == null) return;
        for (Exercise ex : addWork.get(target)) {
            if (ex.getExerciseId() == exeId) {
                ex.setSet(set);
                break;
            }
        }
    }

    public void changeReps(int exeId, int id, int reps) {
        User target = null;
        for (User u : addWork.keySet()) {
            if (u.getFreakId() == id) {
                target = u;
                break;
            }
        }
        if (target == null) return;
        for (Exercise ex : addWork.get(target)) {
            if (ex.getExerciseId() == exeId) {
                ex.setReps(reps);
                break;
            }
        }
    }

    public void changeName(int exeId, int id, String name) {
        User target = null;
        for (User u : addWork.keySet()) {
            if (u.getFreakId() == id) {
                target = u;
                break;
            }
        }
        if (target == null) return;
        for (Exercise ex : addWork.get(target)) {
            if (ex.getExerciseId() == exeId) {
                ex.setExerciseName(name);
                break;
            }
        }

    }

    public void changeDate(int exeId, int id, LocalDate date) {

        User target = null;
        for (User u : addWork.keySet()) {
            if (u.getFreakId() == id) {
                target = u;
                break;
            }
        }
        if (target == null) return;
        for (Exercise ex : addWork.get(target)) {
            if (ex.getExerciseId() == exeId) {
                ex.setDate(date);
                break;
            }
        }
    }
}
