package com.fit.fitnessfreak.features.addWorkout;

public interface IAddModelController {
}
