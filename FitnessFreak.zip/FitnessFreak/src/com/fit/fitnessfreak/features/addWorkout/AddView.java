package com.fit.fitnessfreak.features.addWorkout;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.features.dashboard.DashBoardView;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.time.format.DateTimeFormatter;

public class AddView implements IControllerAddView {
    private final IAddViewController addController;
    private static final Scanner sc=new Scanner(System.in);

    public AddView(){
        addController=new AddController(this);
    }

    public void addWorkout() {
        System.out.println("=====Add Workout====");
        int id=0;
        while(true) {
            try {
                System.out.println("Enter the Freak Id: ");
                id = Integer.parseInt(sc.nextLine());
                if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }
        int exeId=0;
        while(true) {
            try {
                System.out.println("Enter the Exercise Id: ");
                exeId = Integer.parseInt(sc.nextLine());
                if(!((exeId>='a' && exeId<='z') || (exeId>='A' && exeId<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }
        LocalDate date=null;
        while(true) {
            try {
                System.out.println("Enter the date (dd-MM-yyyy)");
                String input = sc.nextLine();
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                date = LocalDate.parse(input, dateTimeFormatter);
                break;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid...try again");
            }
        }
        System.out.println("Enter the exercise Name: ");
        String name=sc.nextLine();

        int reps=0;
        while(true) {
            try {
                System.out.println("Enter the how many reps(Min 10): ");
                reps=Integer.parseInt(sc.nextLine());
                if(!((reps>='a' && reps<='z') || (reps>='A' && reps<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid reps");
            }
        }
        int set=0;
        while(true) {
            try {
                System.out.println("Enter the set for this workout(10 reps per set): ");
                set=Integer.parseInt(sc.nextLine());
                if(set==reps/10){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid set");
            }
        }
        if(addController.addWork(id,exeId,date,name,reps,set)){
            System.out.println("Successfully Added");
        }else{
            System.out.println("First Add the user");
        }
    }

    public void viewWorkout() {
       /* int id=0;
        while(true) {
            try {
                System.out.println("Enter the Freak Id(Which person exercises): ");
                id = Integer.parseInt(sc.nextLine());
                if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }*/
        Map<User, List<Exercise>> map=addController.getWork();

        System.out.println("====Freak Workout Details====");

        for(User use: map.keySet()){
            System.out.println(use.getFreakId()+": "+use.getFreakName()+"("+use.getFreakLevel()+")---->");
        }
        System.out.println();
        System.out.println("S.No |      Date      |   Exercise  |  Reps  |  Set  |");
        System.out.println("------------------------------------------------------");
        for(List<Exercise> l: map.values()){
            for(Exercise exe: l){
                System.out.println(exe.getExerciseId()+"    |  "+exe.getDate()+"    |  "+
                        exe.getExerciseName()+"       |  "+exe.getReps()+"    |  "+exe.getSet());
            }
        }
    }

    public void viewWorkoutDate() {
        while(true) {
            new DashBoardView().viewUser();
            System.out.println("Enter the valid freak details you want (Enter their id): ");
            int id = 0;
            while (true) {
                try {
                    System.out.println("Enter the Freak Id: ");
                    id = Integer.parseInt(sc.nextLine());
                    if (!((id >= 'a' && id <= 'z') || (id >= 'A' && id <= 'Z'))) {
                        List<User> list = addController.viewUser();
                        for (User us : list) {
                            if (us.getFreakId() == id) {
                                break;
                            }
                        }
                        break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Please provide the valid id");
                }
            }
            LocalDate date = null;
            while(true) {
                try {
                    System.out.println("Enter the date of the exercise do you want to see(dd-MM-yyyy)");
                    String input = sc.nextLine();
                    DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                    date = LocalDate.parse(input, dateTimeFormatter);
                    break;
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid Date");
                }
            }
            if (viewWorkout(id, date)) {
               break;
            }
        }
    }

    public boolean viewWorkout(int id,LocalDate date){
        Map<User, List<Exercise>> map=addController.getWork();

        System.out.println("====Freak Workout Details====");

        for(User use: map.keySet()) {
            if (use.getFreakId() == id) {
                System.out.println(use.getFreakName() + "(" + use.getFreakLevel() + ")---->");

                System.out.println();
                System.out.println("S.No |      Date      |   Exercise  |  Reps  |  Set  |");
                System.out.println("------------------------------------------------------");
                for (Exercise exe : map.get(use)) {

                    if (exe.getDate().equals(date)) {
                        System.out.println(exe.getExerciseId() + "    |  " + exe.getDate() + "    |  " +
                                exe.getExerciseName() + "       |  " + exe.getReps() + "    |  " + exe.getSet());
                        return true;
                    }
                }
                System.out.println("There is no exercise in that date");
            }
        }
        return false;
    }
}
