package com.fit.fitnessfreak.features.addWorkout;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class AddController implements IAddViewController,IAddModelController{
    private final IControllerAddView addView;
    private final IControllerAddModel addModel;

    public AddController(AddView addView){
        this.addView=addView;
        addModel=new AddModel(this);
    }

    @Override
    public boolean addWork(int id, int exeId, LocalDate date, String name, int reps, int set) {
       return addModel.addWork(id,exeId,date,name,reps,set);
    }

    @Override
    public Map<User, List<Exercise>> getWork() {
        return addModel.getWork();
    }

    @Override
    public List<User> viewUser() {
        return addModel.viewUser();
    }
}
