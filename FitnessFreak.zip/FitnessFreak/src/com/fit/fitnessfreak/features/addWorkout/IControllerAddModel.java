package com.fit.fitnessfreak.features.addWorkout;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public interface IControllerAddModel {
    abstract boolean addWork(int id, int exeId, LocalDate date, String name, int reps, int set);

    abstract Map<User, List<Exercise>> getWork();

    abstract List<User> viewUser();
}
