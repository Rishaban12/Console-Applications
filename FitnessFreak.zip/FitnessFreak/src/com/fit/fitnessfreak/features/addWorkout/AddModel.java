package com.fit.fitnessfreak.features.addWorkout;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.repo.FreakDb;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class AddModel implements IControllerAddModel{
    private final IAddModelController addController;
    public AddModel(AddController addController){
        this.addController=addController;
    }

    @Override
    public boolean addWork(int id, int exeId, LocalDate date, String name, int reps, int set) {
        return FreakDb.getInstance().addWork(id,exeId,date,name,reps,set);
    }

    @Override
    public Map<User, List<Exercise>> getWork() {
        return FreakDb.getInstance().viewWork();
    }

    @Override
    public List<User> viewUser() {
        return FreakDb.getInstance().viewUser();
    }

}
