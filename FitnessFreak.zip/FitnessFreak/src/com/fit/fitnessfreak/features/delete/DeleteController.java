package com.fit.fitnessfreak.features.delete;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.util.List;
import java.util.Map;

public class DeleteController implements IDeleteViewController,IDeleteModelController{
    private final IControllerDeleteView deleteView;
    private final IControllerDeleteModel deleteModel;

    public DeleteController(DeleteView deleteView){
        this.deleteView=deleteView;
        deleteModel=new DeleteModel(this);
    }

    @Override
    public Map<User, List<Exercise>> sent(int id) {
         return deleteModel.sent(id);

    }

    @Override
    public void deleteAll(int id) {
         deleteModel.deleteAll(id);
    }

    @Override
    public void ExDelete(int id,int exeId) {
        deleteModel.ExDelete(id,exeId);
    }

    @Override
    public boolean check(int id) {
        return deleteModel.check(id);
    }
}
