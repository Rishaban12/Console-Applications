package com.fit.fitnessfreak.features.delete;

public interface IDeleteModelController {
}
