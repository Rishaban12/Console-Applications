package com.fit.fitnessfreak.features.delete;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.util.List;
import java.util.Map;

public interface IDeleteViewController {
    abstract Map<User, List<Exercise>> sent(int id);

    abstract void deleteAll(int id);

    abstract void ExDelete(int id,int exeId);

    abstract boolean check(int id);
}
