package com.fit.fitnessfreak.features.delete;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.repo.FreakDb;

import java.util.List;
import java.util.Map;

public class DeleteModel implements IControllerDeleteModel{
    private final IDeleteModelController deleteController;

    public DeleteModel(DeleteController deleteController){
        this.deleteController=deleteController;
    }

    @Override
    public Map<User, List<Exercise>> sent(int id) {
        return FreakDb.getInstance().getDeletePerson(id);
    }

    @Override
    public void deleteAll(int id) {
       FreakDb.getInstance().deleteAll(id);
    }

    @Override
    public void ExDelete(int id,int exeId) {
        FreakDb.getInstance().ExDelete(id,exeId);
    }

    @Override
    public boolean check(int id) {
        return FreakDb.getInstance().check(id);
    }
}
