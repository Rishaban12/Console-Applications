package com.fit.fitnessfreak.features.delete;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.features.addWorkout.AddView;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class DeleteView implements IControllerDeleteView{
    private final IDeleteViewController deleteController;
    private final Scanner sc=new Scanner(System.in);

    public DeleteView(){
        deleteController=new DeleteController(this);
    }

    public void deleteWorkout() {
       while(true) {
            new AddView().viewWorkout();
            System.out.println("Enter the which person id do you delete: ");
            int id = 0;
            while (true) {
                try {
                    System.out.println("Enter the Freak Id: ");
                    id = Integer.parseInt(sc.nextLine());

                    if (!((id >= 'a' && id <= 'z') || (id >= 'A' && id <= 'Z')) && deleteController.check(id)) {
                        break;
                    }
                    if(!deleteController.check(id)){
                        System.out.println("There is not person id");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Please provide the valid id");
                }
            }
            print(id);
            boolean flag = true;
            while (flag) {
                System.out.println("1. Enter the which exercise id do you want to delete: ");
                System.out.println("2. Want to delete all exercise for their person: ");
                System.out.println("3. Exit");
                int opt = Integer.parseInt(sc.nextLine());

                switch (opt) {
                    case 1:
                    int exeId = 0;
                    while (true) {
                        try {
                            System.out.println("Enter the exercise Id: ");
                            exeId = Integer.parseInt(sc.nextLine());
                            if (!((exeId >= 'a' && exeId <= 'z') || (exeId >= 'A' && exeId <= 'Z'))) {
                                break;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please provide the valid id");
                        }
                    }
                       deleteController.ExDelete(id,exeId);
                        System.out.println("Successfully deleted");
                        print(id);
                        break;
                    case 2:
                        deleteController.deleteAll(id);
                        System.out.println("Successfully deleted");
                        break;
                    case 3:
                        flag=false;
                        break;
                    default:
                        System.out.println("Please provide the valid option");
                }
            }
            break;
        }
    }
    public void print(int id){
        Map<User, List<Exercise>> map=deleteController.sent(id);

        System.out.println("====Delete Person Details====");
        for(User use: map.keySet()){
            System.out.println(use.getFreakId()+": "+use.getFreakName()+"("+use.getFreakLevel()+")---->");
        }
        System.out.println();
        System.out.println("S.No |      Date      |   Exercise  |  Reps  |  Set  |");
        System.out.println("------------------------------------------------------");
        for(List<Exercise> l: map.values()){
            for(Exercise exe: l){
                System.out.println(exe.getExerciseId()+"    |  "+exe.getDate()+"    |  "+
                        exe.getExerciseName()+"       |  "+exe.getReps()+"    |  "+exe.getSet());
            }
        }
    }
}
