package com.fit.fitnessfreak.features.dashboard;

import com.fit.fitnessfreak.dto.User;

import java.util.List;

public interface IDashBoardViewController {

    abstract void add(int id, String name, int age, String level);

    abstract List<User> viewUser();
}
