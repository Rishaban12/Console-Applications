package com.fit.fitnessfreak.features.dashboard;

import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.features.addWorkout.AddView;
import com.fit.fitnessfreak.features.delete.DeleteView;
import com.fit.fitnessfreak.features.update.UpdateView;

import java.util.List;
import java.util.Scanner;

public class DashBoardView implements IControllerDashBoardView{
    private final IDashBoardViewController dashBoardController;
    private final Scanner sc=new Scanner(System.in);

    public DashBoardView(){
        dashBoardController=new DashBoardController(this);
    }

    public void initView() {
        //System.out.println(dashBoardController);
        boolean flag=true;
        int opt=0;
       while(flag){
           print();
          opt=Integer.parseInt(sc.nextLine());

            switch (opt) {
                case 1:
                    addUser();
                    break;
                case 2:
                    viewUser();
                    break;
                case 3:
                    new AddView().addWorkout();
                    break;
                case 4:
                    new AddView().viewWorkout();
                    break;
                case 5:
                    new AddView().viewWorkoutDate();
                    break;
                case 6:
                    new UpdateView().viewUpdate();
                    break;
                case 7:
                    new DeleteView().deleteWorkout();
                    break;
                case 8:
                    System.out.println("App is Quitting...");
                    flag=false;
                    break;
                default:
                    System.out.println("Please provide the valid Option");
            }
       }
    }
    public void print(){
        System.out.println("=====DashBoard=====");
        System.out.println("1. Add User");
        System.out.println("2. View all User");
        System.out.println("3. Add Workout");
        System.out.println("4. View all Workout");
        System.out.println("5. View Workout by date");
        System.out.println("6. Update(edit) the particular Workout");
        System.out.println("7. Delete Workout");
        System.out.println("8. Quit");
        System.out.println("Enter the valid option(1-8): ");
    }

    public void addUser(){
        int id=0;
          while(true) {
              try {
                  System.out.println("====Add User====");
                  System.out.println("Enter the Freak Id: ");
                  id = Integer.parseInt(sc.nextLine());
                  if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                      break;
                  }
              } catch (NumberFormatException e) {
                  System.out.println("Please provide the valid id");
              }
          }
        System.out.println("Enter the Freak Name: ");
          String name=sc.nextLine();
          int age=0;
        while(true) {
            try {
                System.out.println("Enter the Freak Age: ");
                age = Integer.parseInt(sc.nextLine());
                if(!((age>='a' && age<='z') || (age>='A' && age<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid age");
            }
        }
        System.out.println("Enter the Freak Level (Beginner/Intermediate/Expert): ");
        String level=sc.nextLine();
        dashBoardController.add(id,name,age,level);
    }

    @Override
    public void sentRes() {
        System.out.println("Successfully add the user");
    }

    public void viewUser(){
        List<User> list=dashBoardController.viewUser();
        System.out.println("=====Freak Details=====");
        for(User use: list){
            System.out.println("Freak Id: "+use.getFreakId()+"\n"+"Freak Name: "+
                    use.getFreakName()+"\n"+"Freak Age: "+use.getFreakAge()+"\n"+"Freak Level: "+use.getFreakLevel());
            System.out.println("---------------------------");
        }
    }
}
