package com.fit.fitnessfreak.features.dashboard;

import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.repo.FreakDb;

import java.util.Collections;
import java.util.List;

public class DashBoardModel implements IControllerDashBoardModel{
    private final IDashBoardModelController dashBoardController;

    public DashBoardModel(DashBoardController dashBoardController){
        this.dashBoardController=dashBoardController;
    }

    @Override
    public void add(int id, String name, int age, String level) {
        FreakDb.getInstance().add(id,name,age,level);
        dashBoardController.sentRes();
    }

    @Override
    public List<User> viewUser() {
        return FreakDb.getInstance().viewUser();
    }
}
