package com.fit.fitnessfreak.features.dashboard;

public interface IControllerDashBoardView {
    abstract void sentRes();
}
