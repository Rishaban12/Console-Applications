package com.fit.fitnessfreak.features.dashboard;

public interface IDashBoardModelController {
    abstract void sentRes();
}
