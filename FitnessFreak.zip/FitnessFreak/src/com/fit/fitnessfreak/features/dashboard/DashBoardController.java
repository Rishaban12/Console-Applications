package com.fit.fitnessfreak.features.dashboard;

import com.fit.fitnessfreak.dto.User;

import java.util.Collections;
import java.util.List;

public class DashBoardController implements IDashBoardViewController,IDashBoardModelController{
    private final IControllerDashBoardView dashBoardView;
    private final IControllerDashBoardModel dashBoardModel;

    public DashBoardController(DashBoardView dashBoardView){
        this.dashBoardView=dashBoardView;
        dashBoardModel=new DashBoardModel(this);
    }

    @Override
    public void add(int id, String name, int age, String level) {
          dashBoardModel.add(id,name,age,level);
    }

    @Override
    public List<User> viewUser() {
        return dashBoardModel.viewUser();
    }

    @Override
    public void sentRes() {
        dashBoardView.sentRes();
    }
}
