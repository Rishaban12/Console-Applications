package com.fit.fitnessfreak.features.update;

public interface IUpdateModelController {
}
