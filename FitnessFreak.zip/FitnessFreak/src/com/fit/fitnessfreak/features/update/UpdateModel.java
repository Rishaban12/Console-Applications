package com.fit.fitnessfreak.features.update;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.repo.FreakDb;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class UpdateModel implements IControllerUpdateModel{
    private final IUpdateModelController updateController;

    public UpdateModel(UpdateController updateController){
        this.updateController=updateController;
    }

    @Override
    public Map<User, List<Exercise>> viewById(int id) {
        return FreakDb.getInstance().viewById(id);
    }

    @Override
    public void changeSet(int exeId, int id, int set) {
         FreakDb.getInstance().changeSet(exeId,id,set);
    }

    @Override
    public void changeReps(int exeId, int id, int reps) {
        FreakDb.getInstance().changeReps(exeId,id,reps);
    }

    @Override
    public void changeName(int exeId, int id, String name) {
        FreakDb.getInstance().changeName(exeId,id,name);
    }

    @Override
    public void changeDate(int exeId, int id, LocalDate date) {
        FreakDb.getInstance().changeDate(exeId,id,date);
    }
}
