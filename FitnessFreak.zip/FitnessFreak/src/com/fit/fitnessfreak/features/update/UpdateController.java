package com.fit.fitnessfreak.features.update;


import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class UpdateController implements IUpdateViewController,IUpdateModelController{
    private final IControllerUpdateView updateView;
    private final IControllerUpdateModel updateModel;

    public UpdateController(UpdateView updateView){
        this.updateView=updateView;
        updateModel=new UpdateModel(this);
    }

    @Override
    public Map<User, List<Exercise>> viewById(int id) {
        return updateModel.viewById(id);
    }

    @Override
    public void changeSet(int exeId, int id, int set) {
          updateModel.changeSet(exeId,id,set);
    }

    @Override
    public void changeReps(int exeId, int id, int reps) {
         updateModel.changeReps(exeId,id,reps);
    }

    @Override
    public void changeName(int exeId, int id, String name) {
        updateModel.changeName(exeId,id,name);
    }

    @Override
    public void changeDate(int exeId, int id, LocalDate date) {
        updateModel.changeDate(exeId,id,date);
    }
}
