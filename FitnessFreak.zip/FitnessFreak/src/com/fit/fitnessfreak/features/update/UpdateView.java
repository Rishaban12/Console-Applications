package com.fit.fitnessfreak.features.update;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;
import com.fit.fitnessfreak.features.addWorkout.AddView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class UpdateView implements IControllerUpdateView{
    private final IUpdateViewController updateController;
    private final Scanner sc=new Scanner(System.in);

    public UpdateView(){
        updateController=new UpdateController(this);
    }
    public void viewUpdate() {
        new AddView().viewWorkout();
        System.out.println("Which person id do you want to edit(Enter their id): ");
        int id=0;
        while(true) {
            try {
                System.out.println("Enter the Freak Id: ");
                id = Integer.parseInt(sc.nextLine());
                if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }
        viewById(id);
        int exeId=0;
        System.out.println("Which exercise id do you want to change for this freak: ");
        while(true){
            try {
                System.out.println("Enter the Exercise Id: ");
                exeId = Integer.parseInt(sc.nextLine());
                if(!((exeId>='a' && exeId<='z') || (exeId>='A' && exeId<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }
        int opt=0;
       f: while(true){
            print();
            opt=Integer.parseInt(sc.nextLine());
            switch (opt){
                case 1:
                    LocalDate date=null;
                    while(true) {
                        try {
                            System.out.println("Enter the date (dd-MM-yyyy)");
                            String input = sc.nextLine();
                            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                            date = LocalDate.parse(input, dateTimeFormatter);
                            break;
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid...try again");
                        }
                    }
                    updateController.changeDate(exeId,id,date);
                    viewById(id);
                    break;
                case 2:
                    String name="";
                   l: while(true) {
                        try {
                            System.out.println("Enter the Exercise name: ");
                            name = sc.nextLine();
                            if (!(name.equals(""))) {
                                break l;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please provide the valid name");
                        }
                    }
                    updateController.changeName(exeId,id,name);
                    viewById(id);
                    break;
                case 3:
                   int reps=0;
                    l: while(true) {
                        try {
                            System.out.println("Enter the reps: ");
                            reps = Integer.parseInt(sc.nextLine());
                            if (!((reps>='a' && reps<='z') || (reps>='A' && reps<='Z'))) {
                                break l;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please provide the reps");
                        }
                    }
                    updateController.changeReps(exeId,id,reps);
                    viewById(id);
                    break;
                case 4:
                    int set=0;
                    l: while(true) {
                        try {
                            System.out.println("Enter the set: ");
                            set = Integer.parseInt(sc.nextLine());
                            if (!((set>='a' && set<='z') || (set>='A' && set<='Z'))) {
                                break l;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please provide the valid set");
                        }
                    }
                    updateController.changeSet(exeId,id,set);
                    viewById(id);
                    break;
                case 5:
                    break f;
                default:
                    System.out.println("Please provide the valid option");
            }
        }
    }
    public void viewById(int id){
        Map<User, List<Exercise>> map=updateController.viewById(id);

        for(User use: map.keySet()){
            System.out.println(use.getFreakId()+": "+use.getFreakName()+"("+use.getFreakLevel()+")---->");
        }
        System.out.println();
        System.out.println("S.No |      Date      |   Exercise  |  Reps  |  Set  |");
        System.out.println("------------------------------------------------------");
        for(List<Exercise> l: map.values()){
            for(Exercise exe: l){
                System.out.println(exe.getExerciseId()+"    |  "+exe.getDate()+"    |  "+
                        exe.getExerciseName()+"       |  "+exe.getReps()+"    |  "+exe.getSet());
            }
        }
    }
    public void print(){
        System.out.println("1. Change the date");
        System.out.println("2. Change the exercise Name");
        System.out.println("3. Change reps");
        System.out.println("4. Change set");
        System.out.println("5. Exit");
        System.out.println("Choose the option(1-4)");
    }
}
