package com.fit.fitnessfreak.features.update;

import com.fit.fitnessfreak.dto.Exercise;
import com.fit.fitnessfreak.dto.User;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface IUpdateViewController {
    abstract Map<User, List<Exercise>> viewById(int id);

    abstract void changeSet(int exeId, int id, int set);

    abstract void changeReps(int exeId, int id, int reps);

    abstract void changeName(int exeId, int id, String name);

    abstract void changeDate(int exeId, int id, LocalDate date);
}
