package com.fit.fitnessfreak.dto;

public class User {
    private int freakId;
    private String freakName;
    private int freakAge;
    private String freakLevel;

    public User(int freakId,String freakName,int freakAge,String freakLevel) {
        this.freakId = freakId;
        this.freakName=freakName;
        this.freakAge=freakAge;
        this.freakLevel=freakLevel;
    }

    public int getFreakId() {
        return freakId;
    }

    public void setFreakId(int freakId) {
        this.freakId = freakId;
    }

    public String getFreakName() {
        return freakName;
    }

    public void setFreakName(String freakName) {
        this.freakName = freakName;
    }

    public int getFreakAge() {
        return freakAge;
    }

    public void setFreakAge(int freakAge) {
        this.freakAge = freakAge;
    }

    public String getFreakLevel() {
        return freakLevel;
    }

    public void setFreakLevel(String freakLevel) {
        this.freakLevel = freakLevel;
    }
}
