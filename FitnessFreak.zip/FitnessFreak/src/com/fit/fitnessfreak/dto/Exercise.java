package com.fit.fitnessfreak.dto;

import java.time.LocalDate;

public class Exercise {
    private int freakId;
    private int exerciseId;
    private LocalDate date;
    private String exerciseName;
    private int set;
    private int reps;

    public Exercise(int freakId,int exerciseId,LocalDate date,String exerciseName,int set,int reps) {
        this.freakId = freakId;
        this.exerciseId=exerciseId;
        this.date=date;
        this.exerciseName=exerciseName;
        this.set=set;
        this.reps=reps;
    }

    public int getFreakId() {
        return freakId;
    }

    public void setFreakId(int freakId) {
        this.freakId = freakId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getExerciseName() {
        return exerciseName;
    }

    public void setExerciseName(String exerciseName) {
        this.exerciseName = exerciseName;
    }

    public int getSet() {
        return set;
    }

    public void setSet(int set) {
        this.set = set;
    }

    public int getReps() {
        return reps;
    }
    public void setReps(int reps) {
        this.reps = reps;
    }

    public int getExerciseId() {
        return exerciseId;
    }

    public void setExerciseId(int exerciseId) {
        this.exerciseId = exerciseId;
    }
}
