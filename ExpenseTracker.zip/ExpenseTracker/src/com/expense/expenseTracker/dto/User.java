package com.expense.expenseTracker.dto;

public class User {
    private String name;
    private String email;
    private double income;
    private String month;


    public User(String name,String email,double income,String month) {
        this.name = name;
        this.email=email;
        this.income=income;
        this.month=month;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

}
