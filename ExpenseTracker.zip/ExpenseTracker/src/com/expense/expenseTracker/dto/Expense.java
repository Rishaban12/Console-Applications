package com.expense.expenseTracker.dto;

import java.time.LocalDate;

public class Expense {
    private int transId;
    private LocalDate date;
    private String category;
    private double expense;

    public Expense(int transId,LocalDate date,String category,double expense) {
        this.transId = transId;
        this.date=date;
        this.category=category;
        this.expense=expense;
    }

    public int getTransId() {
        return transId;
    }

    public void setTransId(int transId) {
        this.transId = transId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getExpense() {
        return expense;
    }

    public void setExpense(double expense) {
        this.expense = expense;
    }
}
