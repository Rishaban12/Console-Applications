package com.expense.expenseTracker.dto;

public class LoginCredentials {
    private String userName;
    private int password;

    public LoginCredentials(String userName,int password) {
        this.userName = userName;
        this.password=password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getPassword() {
        return password;
    }

    public void setPassword(int password) {
        this.password = password;
    }
}
