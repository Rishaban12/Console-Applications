package com.expense.expenseTracker.features.update;

import java.time.LocalDate;

public class UpdateController implements IUpdateViewController,IUpdateModelController{
    private final IControllerUpdateView updateView;
    private final IControllerUpdateModel updateModel;

    public UpdateController(UpdateView updateView){
        this.updateView=updateView;
        updateModel=new UpdateModel(this);
    }

    @Override
    public void changeDate(LocalDate date, int id) {
        updateModel.changeDate(date,id);
    }

    @Override
    public void changeCategory(String category, int id) {
       updateModel.changeCategory(category,id);
    }

    @Override
    public void changeExpense(double expense, int id) {
       updateModel.changeExpense(expense,id);
    }
}
