package com.expense.expenseTracker.features.update;

public interface IUpdateModelController {
}
