package com.expense.expenseTracker.features.update;

public interface IControllerUpdateView {
}
