package com.expense.expenseTracker.features.update;

import com.expense.expenseTracker.features.show.ShowView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class UpdateView implements IControllerUpdateView{
    private final IUpdateViewController updateController;
    private final Scanner sc=new Scanner(System.in);
    private final ShowView showView=new ShowView();

    public UpdateView(){
        updateController=new UpdateController(this);
    }

    public void editExpense() {
        int id=0;
        showView.viewAll();
        f: while(true){
            try {
                System.out.println("Enter the which expense id do you want to change");
                id=Integer.parseInt(sc.nextLine());
                if(!(id>='a' && id<='z') && !(id>='A' && id<='Z')){
                    break f;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter the valid id");
            }
        }
       l: while(true){
            print();
            int opt = Integer.parseInt(sc.nextLine());
            switch (opt) {
                case 1:
                    LocalDate date=null;
                    while(true){
                        try {
                            System.out.println("Enter the new Date (dd-MM-yyyy)");
                            String input = sc.nextLine();
                            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                            date = LocalDate.parse(input, dateTimeFormatter);
                            break;
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid...");
                        }
                    }
                    updateController.changeDate(date,id);
                    showView.dateView(date);
                    break;
                case 2:
                    String category="";
                    while (true){
                        System.out.println("Enter the new category of your expenses(food/rent/petrol): ");
                        category=sc.nextLine();
                        if(!category.equals("") && (category.matches("^[^0-9]*$"))){
                            break;
                        }
                    }
                    updateController.changeCategory(category,id);
                    showView.categoryView(category);
                    break;
                case 3:
                    double expense=0.0;
                    f: while(true){
                        try {
                            System.out.println("Enter your new expenses of your category");
                            expense = Double.parseDouble(sc.nextLine());
                            if(!(expense>='a' && expense<='z') && !(expense>='A' && expense<='Z')){
                                break f;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please enter the valid expense");
                        }
                    }
                    updateController.changeExpense(expense,id);
                    showView.viewAll();
                    break;
                case 4:
                    break l;
                default:
                    System.out.println("Choose the correct option");
            }
        }
    }
    public void print(){
        System.out.println("1. Change the date");
        System.out.println("2. Change the category");
        System.out.println("3. Change the expense");
        System.out.println("4. Exit");
        System.out.println("Choose the option(1-4)");
    }
}
