package com.expense.expenseTracker.features.update;

import java.time.LocalDate;

public interface IUpdateViewController {
    abstract void changeDate(LocalDate date, int id);

    abstract void changeCategory(String category, int id);

    abstract void changeExpense(double expense, int id);
}
