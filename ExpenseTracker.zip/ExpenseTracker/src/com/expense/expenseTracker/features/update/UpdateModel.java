package com.expense.expenseTracker.features.update;

import com.expense.expenseTracker.repo.ExpenseDb;

import java.time.LocalDate;

public class UpdateModel implements IControllerUpdateModel{
    private final IUpdateModelController updateController;

    public UpdateModel(UpdateController updateController){
        this.updateController=updateController;
    }

    @Override
    public void changeDate(LocalDate date, int id) {
        ExpenseDb.getInstance().changeDate(date,id);
    }

    @Override
    public void changeCategory(String category, int id) {
       ExpenseDb.getInstance().changeCategory(category,id);
    }

    @Override
    public void changeExpense(double expense, int id) {
       ExpenseDb.getInstance().changeExpense(expense,id);
    }
}
