package com.expense.expenseTracker.features.show;

import com.expense.expenseTracker.dto.Expense;
import com.expense.expenseTracker.dto.User;

import java.util.List;
import java.util.Map;

public interface IControllerShowModel {
    abstract Map<List<User>, List<Expense>> viewAll();

    abstract double total();

    abstract double getExpense();
}
