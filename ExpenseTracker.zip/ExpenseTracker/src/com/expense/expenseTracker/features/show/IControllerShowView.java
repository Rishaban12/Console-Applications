package com.expense.expenseTracker.features.show;

public interface IControllerShowView {
}
