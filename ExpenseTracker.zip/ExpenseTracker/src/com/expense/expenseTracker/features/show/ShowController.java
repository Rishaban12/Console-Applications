package com.expense.expenseTracker.features.show;


import com.expense.expenseTracker.dto.Expense;
import com.expense.expenseTracker.dto.User;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ShowController implements IShowViewController,IShowModelController{
    private final IControllerShowView showView;
    private final IControllerShowModel showModel;

    public ShowController(ShowView showView){
        this.showView=showView;
        showModel=new ShowModel(this);
    }

    @Override
    public Map<List<User>, List<Expense>> viewAll() {
        return showModel.viewAll();
    }

    @Override
    public double total() {
        return showModel.total();
    }

    @Override
    public double getExpense() {
        return showModel.getExpense();
    }


}
