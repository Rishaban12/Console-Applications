package com.expense.expenseTracker.features.show;

import com.expense.expenseTracker.dto.Expense;
import com.expense.expenseTracker.dto.User;
import com.expense.expenseTracker.features.add.AddView;
import com.expense.expenseTracker.features.delete.DeleteView;
import com.expense.expenseTracker.features.update.UpdateView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class ShowView implements IControllerShowView {
    private final IShowViewController showController;

    private final Scanner sc=new Scanner(System.in);

    public ShowView(){
        showController=new ShowController(this);
    }

    public void initView() {
         f: while (true){
             print();
             int opt=Integer.parseInt(sc.nextLine());
             switch (opt) {
                 case 1:
                     viewAll();
                     break;
                 case 2:
                     String category="";
                     while (true){
                         System.out.println("Enter the category of your expenses(food/rent/petrol): ");
                         category=sc.nextLine();
                         if(!category.equals("") && (category.matches("^[^0-9]*$"))){
                             break;
                         }
                     }
                     categoryView(category);
                     break;
                 case 3:
                     LocalDate date=null;
                     while(true){
                         try {
                             System.out.println("Enter the Date (dd-MM-yyyy)");
                             String input = sc.nextLine();
                             DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                             date = LocalDate.parse(input, dateTimeFormatter);
                             break;
                         } catch (DateTimeParseException e) {
                             System.out.println("Invalid...");
                         }
                     }
                     dateView(date);
                     break;
                 case 4:
                     priorityView();
                     break;
                 case 5:
                     totalView();
                     break;
                 case 6:
                     break f;
                 default:
                     System.out.println("Choose the correct option");
             }
         }
    }

    public void viewAll() {
        Map<List<User>,List<Expense>> map=showController.viewAll();

        for(List<User> use: map.keySet()){
            for(User us: use){
                System.out.println("Name: "+us.getName()+"\n"+"Income: "+us.getIncome()+"\n"+"Month: "+us.getMonth());
            }
        }
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-8s %-14s %-14s %-14s%n","Id","Date","Category","Expense");
        System.out.println("----------------------------------------------------------");
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp){
                System.out.printf("%-8s %-14s %-14s %-14s%n",ex.getTransId(),ex.getDate(),ex.getCategory(),ex.getExpense());
            }
        }
        System.out.println("----------------------------------------------------------");
    }

    public void totalView() {
        double total=showController.total();
        double expenses=showController.getExpense();
        System.out.println("------------------------------");

        System.out.println("Your Income: "+total);
        System.out.println("Total Expenses: "+expenses);
        System.out.println("Remains :"+(total-expenses));
        System.out.println("------------------------------");


    }

    public void dateView(LocalDate date) {
        Map<List<User>,List<Expense>> map=showController.viewAll();
        for(List<User> use: map.keySet()){
            for(User us: use){
                System.out.println("Name: "+us.getName()+"\n"+"Income: "+us.getIncome()+"\n"+"Month: "+us.getMonth());
            }
        }
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-8s %-14s %-14s %-14s%n","Id","Date","Category","Expense");
        System.out.println("----------------------------------------------------------");
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp) {
                if (ex.getDate().equals(date)) {
                    System.out.printf("%-8s %-14s %-14s %-14s%n", ex.getTransId(), ex.getDate(), ex.getCategory(), ex.getExpense());
                }
            }
        }
        System.out.println("----------------------------------------------------------");

    }

    public void priorityView() {
        Map<List<User>,List<Expense>> map=showController.viewAll();
        for(List<User> use: map.keySet()){
            for(User us: use){
                System.out.println("Name: "+us.getName()+"\n"+"Income: "+us.getIncome()+"\n"+"Month: "+us.getMonth());
            }
        }
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-8s %-14s %-14s %-14s%n","Id","Date","Category","Expense");
        System.out.println("----------------------------------------------------------");
        for(List<Expense> exp: map.values()){
            exp.sort(Comparator.comparingDouble(Expense::getExpense).reversed());
            for(Expense ex: exp){
                System.out.printf("%-8s %-14s %-14s %-14s%n",ex.getTransId(),ex.getDate(),ex.getCategory(),ex.getExpense());
            }
        }
        System.out.println("----------------------------------------------------------");

    }

    public void categoryView(String category) {
        Map<List<User>,List<Expense>> map=showController.viewAll();
        for(List<User> use: map.keySet()){
            for(User us: use){
                System.out.println("Name: "+us.getName()+"\n"+"Income: "+us.getIncome()+"\n"+"Month: "+us.getMonth());
            }
        }
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-8s %-14s %-14s %-14s%n","Id","Date","Category","Expense");
        System.out.println("----------------------------------------------------------");
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp) {
                if (ex.getCategory().equals(category)) {
                    System.out.printf("%-8s %-14s %-14s %-14s%n", ex.getTransId(), ex.getDate(), ex.getCategory(), ex.getExpense());
                }
            }
        }
        System.out.println("----------------------------------------------------------");
    }

    public void print(){
        System.out.println("1. View all records");
        System.out.println("2. View by category");
        System.out.println("3. View by date");
        System.out.println("4. View by higher to lower expenses details");
        System.out.println("5. View Total income,Total expenses and Remains");
        System.out.println("6. Exit");
        System.out.println("Choose the option(1-6): ");
    }
}
