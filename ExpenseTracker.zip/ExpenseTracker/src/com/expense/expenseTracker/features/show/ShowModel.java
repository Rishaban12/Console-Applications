package com.expense.expenseTracker.features.show;

import com.expense.expenseTracker.dto.Expense;
import com.expense.expenseTracker.dto.User;
import com.expense.expenseTracker.repo.ExpenseDb;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class ShowModel implements IControllerShowModel{
    private final IShowModelController showController;

    public ShowModel(ShowController showController){
        this.showController=showController;
    }

    @Override
    public Map<List<User>, List<Expense>> viewAll() {
        return ExpenseDb.getInstance().viewAll();
    }

    @Override
    public double total() {
        return ExpenseDb.getInstance().total();
    }

    @Override
    public double getExpense() {
        return ExpenseDb.getInstance().getExpense();
    }


}
