package com.expense.expenseTracker.features.dashboard;

import com.expense.expenseTracker.features.add.AddView;
import com.expense.expenseTracker.features.delete.DeleteView;
import com.expense.expenseTracker.features.login.LoginView;
import com.expense.expenseTracker.features.show.ShowView;
import com.expense.expenseTracker.features.update.UpdateView;

import java.util.Scanner;

public class DashboardView {
    private final Scanner sc=new Scanner(System.in);

    public void showDashBoard() {
        boolean flag=false;
         while(true) {
             print();
             int opt = Integer.parseInt(sc.nextLine());
             switch (opt) {
                 case 1:
                     new AddView().addUser();
                     break;
                 case 2:
                     new AddView().addExpense();
                     break;
                 case 3:
                     new ShowView().initView();
                     break;
                 case 4:
                     new UpdateView().editExpense();
                     break;
                 case 5:
                     new DeleteView().deleteExpense();
                     break;
                 case 6:
                     flag = true;
                     break;
                 default:
                     System.out.println("Choose the correct option");
             }
             if(flag) {
                 break;
             }
         }
         if(flag) {
             System.out.println("Do you want to login again:(y/n) ");
             String opt=sc.nextLine();
             if(opt.equals("Y")|| opt.equals("y")){
                 new LoginView().initLogin();
             }
         }
    }
    public void print(){
        System.out.println("=========Dashboard=========");
        System.out.println("1. Add the User details and your monthly income");
        System.out.println("2. Add the expenses");
        System.out.println("3. View the recorded transaction");
        System.out.println("4. Update the expenses");
        System.out.println("5. Delete the expenses");
        System.out.println("6. Exit");
        System.out.println("Choose the option(1-6)");
    }
}
