package com.expense.expenseTracker.features.delete;

public interface IControllerDeleteView {
}
