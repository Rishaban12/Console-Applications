package com.expense.expenseTracker.features.delete;

import java.time.LocalDate;

public interface IControllerDeleteModel {
    abstract boolean deleteById(int id);

    abstract boolean deleteByDate(LocalDate date);

    abstract void deleteAll();
}
