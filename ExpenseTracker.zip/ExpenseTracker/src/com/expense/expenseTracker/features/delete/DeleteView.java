package com.expense.expenseTracker.features.delete;

import com.expense.expenseTracker.features.show.ShowView;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class DeleteView implements IControllerDeleteView{
    private final IDeleteViewController deleteController;
    private final Scanner sc=new Scanner(System.in);
    private final ShowView showView=new ShowView();

    public DeleteView(){
        deleteController=new DeleteController(this);
    }
    public void deleteExpense() {
       f: while (true) {
        print();
            int opt = Integer.parseInt(sc.nextLine());
            switch (opt) {
                case 1:
                    showView.viewAll();
                    deleteController.deleteAll();
                    System.out.println("Successfully added");
                    showView.viewAll();
                    break;
                case 2:
                    showView.viewAll();
                    LocalDate date=null;
                    while(true){
                        try {
                            System.out.println("Enter the Date (dd-MM-yyyy)");
                            String input = sc.nextLine();
                            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                            date = LocalDate.parse(input, dateTimeFormatter);
                            break;
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid...");
                        }
                    }
                    if(deleteController.deleteByDate(date)){
                    System.out.println("Successfully added");
                        }else{
                          System.out.println("Its Already Empty...");
                        }
                    showView.viewAll();
                    break;
                case 3:
                    showView.viewAll();
                    int id=0;
                    l: while(true){
                        try {
                            System.out.println("Enter the expense id");
                            id=Integer.parseInt(sc.nextLine());
                            if(!(id>='a' && id<='z') && !(id>='A' && id<='Z')){
                                break l;
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please enter the valid id");
                        }
                    }
                    if(deleteController.deleteById(id)) {
                        System.out.println("Successfully added");
                    }else{
                        System.out.println("Its Already Empty...");
                    }
                    showView.viewAll();
                    break;
                case 4:
                    break f;
                default:
                    System.out.println("Choose the correct option");
            }
        }
    }

    public void print(){
        System.out.println("1. Delete all the expenses");
        System.out.println("2. Delete by date");
        System.out.println("3. Delete by Id");
        System.out.println("4. Exit");
        System.out.println("Choose the option(1-4)");
    }
}
