package com.expense.expenseTracker.features.delete;

import java.time.LocalDate;

public class DeleteController implements IDeleteViewController,IDeleteModelController{
    private final IControllerDeleteView deleteView;
    private final IControllerDeleteModel deleteModel;

    public DeleteController(DeleteView deleteView){
        this.deleteView=deleteView;
        deleteModel=new DeleteModel(this);
    }

    @Override
    public void deleteAll() {
       deleteModel.deleteAll();
    }

    @Override
    public boolean deleteByDate(LocalDate date) {
        return deleteModel.deleteByDate(date);
    }

    @Override
    public boolean deleteById(int id) {
        return deleteModel.deleteById(id);
    }
}
