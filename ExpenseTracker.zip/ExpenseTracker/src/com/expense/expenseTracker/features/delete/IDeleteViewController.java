package com.expense.expenseTracker.features.delete;

import java.time.LocalDate;

public interface IDeleteViewController {
    abstract void deleteAll();

    abstract boolean deleteByDate(LocalDate date);

    abstract boolean deleteById(int id);
}
