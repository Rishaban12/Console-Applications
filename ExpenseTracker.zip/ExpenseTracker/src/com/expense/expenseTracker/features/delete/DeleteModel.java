package com.expense.expenseTracker.features.delete;

import com.expense.expenseTracker.repo.ExpenseDb;

import java.time.LocalDate;

public class DeleteModel implements IControllerDeleteModel {
    private final IDeleteModelController deleteController;

    public DeleteModel(DeleteController deleteController){
        this.deleteController=deleteController;
    }

    @Override
    public boolean deleteById(int id) {
        return ExpenseDb.getInstance().deleteById(id);
    }

    @Override
    public boolean deleteByDate(LocalDate date) {
        return ExpenseDb.getInstance().deleteByDate(date);
    }

    @Override
    public void deleteAll() {
       ExpenseDb.getInstance().deleteAll();
    }
}
