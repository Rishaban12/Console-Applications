package com.expense.expenseTracker.features.add;

import com.expense.expenseTracker.repo.ExpenseDb;

import java.time.LocalDate;

public class AddModel implements IControllerAddModel{
    private final IAddModelController addController;

    public AddModel(AddController addController){
        this.addController=addController;
    }

    @Override
    public void addUser(String name, String email, double income, String month) {
        ExpenseDb.getInstance().addUser(name,email,income,month);
    }

    @Override
    public boolean addExpense(int id, LocalDate date, String category, double expense) {
        ExpenseDb.getInstance().addExpense(id,date,category,expense);
        return false;
    }
}
