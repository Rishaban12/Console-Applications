package com.expense.expenseTracker.features.add;

import java.time.LocalDate;

public interface IAddViewController {
    abstract void addUser(String name, String email, double income, String month);

    abstract boolean addExpense(int id, LocalDate date, String category, double expense);
}
