package com.expense.expenseTracker.features.add;

public interface IAddModelController {
}
