package com.expense.expenseTracker.features.add;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;
import java.util.Scanner;

public class AddView implements IControllerAddView{
    private final IAddViewController addController;
    private final Scanner sc=new Scanner(System.in);

    public AddView(){
        addController=new AddController(this);
    }

    public void addExpense() {
        int id=0;
        f: while(true){
            try {
                System.out.println("Enter the expense id");
                id=Integer.parseInt(sc.nextLine());
                if(!(id>='a' && id<='z') && !(id>='A' && id<='Z')){
                    break f;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter the valid id");
            }
        }
        LocalDate date=null;
        while(true){
            try {
                System.out.println("Enter the Date (dd-MM-yyyy)");
                String input = sc.nextLine();
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                date = LocalDate.parse(input, dateTimeFormatter);
                break;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid...");
            }
        }
        String category="";
        while (true){
            System.out.println("Enter the category of your expenses(food/rent/petrol): ");
            category=sc.nextLine();
            if(!category.equals("") && (category.matches("^[^0-9]*$"))){
                break;
            }
        }
        double expense=0.0;
        f: while(true){
            try {
                System.out.println("Enter your expenses of your category");
                expense = Double.parseDouble(sc.nextLine());
                if(!(expense>='a' && expense<='z') && !(expense>='A' && expense<='Z')){
                    break f;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter the valid expense");
            }
        }
        boolean check=addController.addExpense(id,date,category,expense);
        if(!check){
            System.out.println("First add the user details and income");
            return;
        }
        System.out.println("Successfully added...");
    }

    public void addUser() {
        String name="";
        while (true){
            System.out.println("Enter your Name");
            name=sc.nextLine();
            if(!name.equals("") && (name.matches("^[^0-9]*$"))){
                break;
            }
        }
        String email="";
        while (true){
            System.out.println("Enter your Email");
            email=sc.nextLine();
            if(!email.equals("")){
                break;
            }
        }
        double income=0.0;
       f: while(true){
            try {
                System.out.println("Enter your Monthly income");
                income = Double.parseDouble(sc.nextLine());
                if(!(income>='a' && income<='z') && !(income>='A' && income<='Z')){
                    break f;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter the valid income");
            }
        }
        String month="";
        while (true){
            System.out.println("Enter the month of your expenses");
            month=sc.nextLine();
            if(!month.equals("") && (month.matches("^[^0-9]*$"))){
                break;
            }
        }
        addController.addUser(name,email,income,month);
        System.out.println("Successfully added");
    }
}
