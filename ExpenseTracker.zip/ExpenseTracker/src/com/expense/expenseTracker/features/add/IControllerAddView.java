package com.expense.expenseTracker.features.add;

public interface IControllerAddView {
}
