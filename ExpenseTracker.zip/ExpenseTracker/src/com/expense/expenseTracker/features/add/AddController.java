package com.expense.expenseTracker.features.add;

import java.time.LocalDate;

public class AddController implements IAddModelController,IAddViewController{
    private final IControllerAddView addView;
    private final IControllerAddModel addModel;

    public AddController(AddView addView){
        this.addView=addView;
        addModel=new AddModel(this);
    }

    @Override
    public void addUser(String name, String email, double income, String month) {
       addModel.addUser(name,email,income,month);
    }

    @Override
    public boolean addExpense(int id, LocalDate date, String category, double expense) {
      return addModel.addExpense(id,date,category,expense);

    }
}
