package com.expense.expenseTracker.features.login;

import com.expense.expenseTracker.repo.ExpenseDb;

public class LoginModel implements IControllerLoginModel{
    private final ILoginModelController loginController;

    public LoginModel(LoginController loginController){
        this.loginController= loginController;
    }

    @Override
    public void validateCredentials(String userName, int password) {
        boolean val= ExpenseDb.getInstance().validateCredentials(userName,password);
        if(val){
            loginController.onLoginSuccess();
        }else{
            loginController.onLoginFailed();
        }
    }

    @Override
    public void newLogin(String userName, int password) {
        ExpenseDb.getInstance().newLogin(userName,password);
        loginController.onLoginSuccess();
    }

    @Override
    public void forgetPass(String user, int pass) {
        ExpenseDb.getInstance().changePass(user,pass);
        loginController.onLoginSuccess();
    }

    @Override
    public boolean check(String user) {
        return ExpenseDb.getInstance().check(user);
    }
}
