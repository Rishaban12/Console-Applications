package com.expense.expenseTracker.features.login;

public interface ILoginModelController {
    abstract void onLoginSuccess();
    abstract void onLoginFailed();
}
