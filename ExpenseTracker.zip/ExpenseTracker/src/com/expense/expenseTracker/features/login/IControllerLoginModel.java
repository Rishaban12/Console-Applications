package com.expense.expenseTracker.features.login;

public interface IControllerLoginModel {
    abstract void validateCredentials(String userName,int password);

    abstract void newLogin(String userName, int password);

    abstract void forgetPass(String user, int pass);

    abstract boolean check(String user);
}
