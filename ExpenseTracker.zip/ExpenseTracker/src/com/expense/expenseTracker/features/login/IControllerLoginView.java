package com.expense.expenseTracker.features.login;

public interface IControllerLoginView {
    abstract void onLoginSuccess();
    abstract void onLoginFailed();
}
