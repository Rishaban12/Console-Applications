package com.expense.expenseTracker.features.login;

public class LoginController implements ILoginViewController,ILoginModelController {

    private final IControllerLoginView loginView;
    private final IControllerLoginModel loginModel;

    public LoginController(LoginView loginView){
        this.loginView=loginView;
        loginModel=new LoginModel(this);
    }

    @Override
    public void validateCredentials(String userName, int password) {
        loginModel.validateCredentials(userName,password);
    }

    @Override
    public void newLogin(String userName, int password) {
        loginModel.newLogin(userName,password);
    }

    @Override
    public void forgetPass(String user, int pass) {
       loginModel.forgetPass(user,pass);
    }

    @Override
    public boolean check(String user) {
        return loginModel.check(user);
    }

    public void onLoginSuccess(){
        loginView.onLoginSuccess();
    }
    public void onLoginFailed(){
        loginView.onLoginFailed();
    }

}
