package com.expense.expenseTracker.features.login;

import com.expense.expenseTracker.dto.LoginCredentials;
import com.expense.expenseTracker.features.dashboard.DashboardView;

import java.util.Scanner;

public class LoginView implements IControllerLoginView{
    private final ILoginViewController loginController;
    private final Scanner sc=new Scanner(System.in);
    private static int num=0;

    public LoginView(){
        loginController=new LoginController(this);
    }

    public void initLogin() {
        int opt=0;
        while(true){
            print();
            opt=Integer.parseInt(sc.nextLine());
            switch (opt){
                case 1:
                    newLogin();
                    break;
                case 2:
                    login();
                    break;
                default:
                    System.out.println("Choose the correct option");
            }
            break;
        }

    }

    public void print(){
        System.out.println("1. New Login");
        System.out.println("2. Already have an account");
        System.out.println("3. Choose the option(1-2)");
    }
    @Override
    public void onLoginSuccess() {
        System.out.println("Successfully Login!!!");
        DashboardView dashboardView=new DashboardView();
        dashboardView.showDashBoard();
    }

    public void onLoginFailed(){
        System.out.println("Login Failed!!");
        num++;
        int n=3-num;
        System.out.println("Remaining attempt: "+ n);
        String opt="";
        if(n==0){
            System.out.println("Forget password (Enter y/n): ");
            opt=sc.nextLine();
            if(opt.equals("Y") || opt.equals("y")){
                int pass=0;
                String user="";
                while (true) {
                    try {
                        System.out.println("Enter your userName");
                        user = sc.nextLine();
                        System.out.println("Enter the new password");
                        pass = Integer.parseInt(sc.nextLine());
                        boolean check = loginController.check(user);
                        if (pass>0) {
                            break;
                        }else {
                            System.out.println("Username is not found");
                        }
                    } catch (Exception e) {
                        System.out.println("Username or password is invalid");
                    }
                }
                loginController.forgetPass(user, pass);
            }else{
                return;
            }
        }
        initLogin();

    }

    public void login(){
        String userName="";
        int password=0;
        while(true){
            try {
                System.out.println("Enter the userName: ");
                userName = sc.nextLine().trim();
                System.out.println("Enter the password(int): ");
                password = Integer.parseInt(sc.nextLine());
                if (password>0) break;

            }catch (NumberFormatException e){
                System.out.println("Username or password is invalid");
            }
        }
        loginController.validateCredentials(userName,password);
    }
    public void newLogin(){
        String userName="";
        int password=0;
        while(true){
            try {
                System.out.println("Enter the userName: ");
                userName = sc.nextLine().trim();
                System.out.println("Enter the password(int): ");
                password = Integer.parseInt(sc.nextLine());
                if (password>0) {
                    break;
                }
            }catch (Exception e){
                System.out.println("Username or password is invalid");
            }
        }
        loginController.newLogin(userName,password);
    }
}
