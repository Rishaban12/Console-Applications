package com.expense.expenseTracker.repo;

import com.expense.expenseTracker.dto.Expense;
import com.expense.expenseTracker.dto.LoginCredentials;
import com.expense.expenseTracker.dto.User;

import javax.jws.soap.SOAPBinding;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseDb {
    private static ExpenseDb s=null;
    private static final List<LoginCredentials> loginCredentials=new ArrayList<>();
    private static final List<Expense> addTrans=new ArrayList<>();
    private static final List<User> adduser=new ArrayList<>();
    private static final Map<List<User>,List<Expense>> map=new HashMap<>();

    public static ExpenseDb getInstance(){
        if(s==null){
            s=new ExpenseDb();
        }
        return s;
    }

    public boolean validateCredentials(String userName, int password) {
        for(LoginCredentials l: loginCredentials){
            if(l.getUserName().equals(userName) && l.getPassword()==password){
                return true;
            }
        }
        return false;
    }

    public void newLogin(String userName,int password){
        LoginCredentials loginCredentials1=new LoginCredentials(userName, password);
        loginCredentials.add(loginCredentials1);
    }

    public void changePass(String userName,int password){
        for(LoginCredentials l: loginCredentials){
            if(l.getUserName().equals(userName)){
                l.setPassword(password);
            }
        }
    }

    public boolean check(String user) {
        for(LoginCredentials l:loginCredentials){
            if(l.getUserName().equals(user)){
                return true;
            }
        }
        return false;
    }

    public void addUser(String name, String email, double income, String month) {
        User user=new User(name,email,income,month);
        adduser.add(user);
    }

    public boolean addExpense(int id, LocalDate date, String category, double expense) {
        if(adduser.isEmpty()){
            return false;
        }
        Expense expense1=new Expense(id,date,category,expense);
        addTrans.add(expense1);
        map.put(adduser,addTrans);
        return true;
    }
    public Map<List<User>,List<Expense>> viewAll(){
        return map;
    }


    public double getExpense() {
        double n=0.0;
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp){
                n+=ex.getExpense();
            }
        }
        return n;
    }

    public double total() {
        double t=0.0;
        for(List<User> user: map.keySet()){
            for(User use: user){
                t=use.getIncome();
            }
        }
        return t;
    }

    public boolean deleteById(int id) {
        for(Expense exp: addTrans){
            if(exp.getTransId()==id){
                addTrans.remove(exp);
                return true;
            }
        }
        return false;
    }

    public boolean deleteByDate(LocalDate date) {
        for(Expense exp: addTrans){
            if(exp.getDate().equals(date)){
                addTrans.remove(exp);
                return true;
            }
        }
        return false;
    }

    public void deleteAll() {
        addTrans.clear();
    }

    public void changeDate(LocalDate date, int id) {
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp){
                if(ex.getTransId()==id){
                    ex.setDate(date);
                }
            }
        }
    }

    public void changeCategory(String category, int id) {
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp){
                if(ex.getTransId()==id){
                    ex.setCategory(category);
                }
            }
        }
    }

    public void changeExpense(double expense, int id) {
        for(List<Expense> exp: map.values()){
            for(Expense ex: exp){
                if(ex.getTransId()==id){
                    ex.setExpense(expense);
                }
            }
        }
    }
}
