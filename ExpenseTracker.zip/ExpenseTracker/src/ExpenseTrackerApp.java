import com.expense.expenseTracker.features.login.LoginView;

public class ExpenseTrackerApp {
    private final static String version="0.0.1";
    public static void main(String[] args) {
       ExpenseTrackerApp expenseTrackerApp=new ExpenseTrackerApp();
       expenseTrackerApp.init();
    }
    public void init(){
        System.out.println("Welcome to our app "+version);
        LoginView loginView=new LoginView();
        loginView.initLogin();
        System.out.println("Thank you for visiting the app");
    }
}
