import com.book.taxiapp.features.book.BookView;

public class TaxiBookApp {
    private final String version="0.0.1";

    public static void main(String[] args) {
        TaxiBookApp taxiBookApp=new TaxiBookApp();
        taxiBookApp.init();
    }
    public void init(){
        System.out.println("Welcome to our Taxi Booing App");
        new BookView().taxiView();
        System.out.println("Thank you for visiting out App");
    }
}
