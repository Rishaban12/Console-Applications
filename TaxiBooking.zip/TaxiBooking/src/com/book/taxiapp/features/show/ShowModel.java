package com.book.taxiapp.features.show;

import com.book.taxiapp.dto.Taxi;
import com.book.taxiapp.repo.TaxiBookDb;

import java.util.Collections;
import java.util.List;

public class ShowModel implements IControllerShowModel{
    private final IShowModelController showController;

    public ShowModel(ShowController showController){
        this.showController=showController;
    }

    @Override
    public List<Taxi> get() {
        return TaxiBookDb.getInstance().get();
    }
}
