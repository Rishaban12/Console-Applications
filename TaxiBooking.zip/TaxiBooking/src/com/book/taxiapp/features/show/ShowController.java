package com.book.taxiapp.features.show;

import com.book.taxiapp.dto.Taxi;

import java.util.Collections;
import java.util.List;

public class ShowController implements IShowViewController,IShowModelController{
    private final IControllerShowView showView;
    private final IControllerShowModel showModel;

    public ShowController(ShowView showView){
        this.showView=showView;
        showModel=new ShowModel(this);
    }

    @Override
    public List<Taxi> get() {
        return showModel.get();
    }
}
