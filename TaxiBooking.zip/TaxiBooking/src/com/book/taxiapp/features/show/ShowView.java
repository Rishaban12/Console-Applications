package com.book.taxiapp.features.show;


import com.book.taxiapp.dto.Bookings;
import com.book.taxiapp.dto.Taxi;

import java.util.List;

public class ShowView implements IControllerShowView {
    private final IShowViewController showController;

    public ShowView(){
        showController=new ShowController(this);
    }
    public void viewDetails() {
        List<Taxi> list=showController.get();

        for(Taxi t: list){
            System.out.println("Taxi "+t.getTaxiId()+" ("+t.getEarnings()+" earnings):");
            System.out.println("--------------------------------------------------------------");
            System.out.printf("%-15s%-10s%-10s%-10s%-10s","CustomerId","From","To","PickUp","Drop");
            System.out.println();
            System.out.println("--------------------------------------------------------------");
            for(Bookings book: t.getBookings()) {
                System.out.printf("%-15s%-10s%-10s%-10s%-10s",book.getCusId(),book.getFrom(),book.getTo(),book.getPickup(),t.getTime());
            }
            System.out.println();
            System.out.println();
        }
    }
}
