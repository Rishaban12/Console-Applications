package com.book.taxiapp.features.show;

import com.book.taxiapp.dto.Taxi;

import java.util.List;

public interface IControllerShowModel {
    abstract List<Taxi> get();
}
