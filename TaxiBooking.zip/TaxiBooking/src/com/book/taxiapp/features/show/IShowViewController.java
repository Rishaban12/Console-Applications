package com.book.taxiapp.features.show;

import com.book.taxiapp.dto.Taxi;

import java.util.List;

public interface IShowViewController {
    abstract List<Taxi> get();
}
