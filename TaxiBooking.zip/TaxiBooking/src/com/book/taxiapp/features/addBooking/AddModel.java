package com.book.taxiapp.features.addBooking;

import com.book.taxiapp.dto.Bookings;
import com.book.taxiapp.dto.Taxi;
import com.book.taxiapp.repo.TaxiBookDb;

import java.util.List;

public class AddModel implements IControllerAddModel{
    private final IAddModelController addController;
    private static int cusInc=0;

    public AddModel(AddController addController){
        this.addController=addController;
    }


        private void allocateTaxi(Taxi t, Bookings b, char drop, int time, char pickup) {
            b.setBookId(t.getTaxiId());
            t.addBookings(b);
            t.setCurPos(drop);
            t.setEarnings(t.getEarnings() + getAmt(pickup, drop));
            t.setTime(time + getTime(pickup, drop));
        }

    @Override
    public void getTaxi(char fir, char sec, int time) {

        Bookings bookings=new Bookings(0,++cusInc,fir,sec,time);

        List<Taxi> taxi=TaxiBookDb.getInstance().get();

        if(samePos(taxi) && !away(fir,taxi) && !isRunning(time,taxi)){
            int id=nearby(fir,taxi);
            for(Taxi tf: taxi) {
                if(tf.getTaxiId()==id) {
                    allocateTaxi(tf,bookings,sec,time,fir);
                    addController.showMessage("Taxi " + tf.getTaxiId() + " is allocated");
                    break;
                }
            }
        }
        else if(samePos(taxi) && !away(fir,taxi)) {
            int id = getMin(taxi);
            for (Taxi t : taxi) {
                if (t.getTaxiId() == id) {
                    allocateTaxi(t,bookings,sec,time,fir);
                    addController.showMessage("Taxi " + t.getTaxiId() + " is allocated");
                    break;
                }
            }
        }
          else if(away(fir,taxi) && !isRunning(time,taxi)){
                int id=nearby(fir,taxi);
                for(Taxi tf: taxi) {
                    if(tf.getTaxiId()==id) {
                        allocateTaxi(tf,bookings,sec,time,fir);
                        addController.showMessage("Taxi " + tf.getTaxiId() + " is allocated");
                        break;
                    }
                }
            }

            else if(isRunning(time,taxi)) {
                addController.showMessage("Rejected..Book Later");
            }
        }

    public int getTime(char fir,char sec){
        return Math.abs(sec-fir);
    }
    public double getAmt(char fir,char sec){
        int km=Math.abs(sec-fir)*15;
        int amt=100 + ((km-5) * 10);
        return amt;
    }

    public int getMin(List<Taxi> taxi){
        double min=Double.MAX_VALUE;
        int id=-1;
        for(Taxi t: taxi){
            if(t.getEarnings()<min){
                min=t.getEarnings();
                id=t.getCurPos();
            }
        }
        return id;
    }

    public boolean samePos(List<Taxi> taxi){
        char ch=taxi.get(0).getCurPos();

        for(Taxi t: taxi){
             if(t.getCurPos()!=ch){
                 return false;
             }else{
                 ch=t.getCurPos();
             }
        }
        return true;
    }

    public boolean isRunning(int time,List<Taxi> taxi){
        for(Taxi t: taxi){
            if(t.getTime()<=time) return false;
        }
        return true;
    }

    public int nearby(char pickup,List<Taxi> taxi){
        int minDist = Integer.MAX_VALUE;
        int id = -1;
        for (Taxi t : taxi) {
            int dist = Math.abs(t.getCurPos() - pickup);
            if (dist < minDist) {
                minDist = dist;
                id = t.getTaxiId();
            }
        }
        return id;
    }
    public boolean away(char fir,List<Taxi> taxi){
        for(Taxi t: taxi){
            if(t.getCurPos()==fir) return false;
        }
        return true;
    }
}
