package com.book.taxiapp.features.addBooking;

import java.util.Scanner;

public class AddView implements IControllerAddView{
   private final IAddViewController addController;
   private final Scanner sc;

   public AddView(){
       addController=new AddController(this);
       sc=new Scanner(System.in);
   }

    public void bookTaxi() {
      char fir=' ';
       while(true){
           System.out.println("Enter the pickup point(A-F): ");
           String op1=sc.nextLine().trim();
           fir=op1.charAt(0);
           if(op1.length()==1) break;
       }
        char sec=' ';
        while(true){
            System.out.println("Enter the pickup point(A-F): ");
            String op1=sc.nextLine().trim();
            sec=op1.charAt(0);
            if(op1.length()==1) break;
        }
        int time=0;
        while(true){
            try {
                System.out.println("Enter the pickup timing(int 24 format hours)");
                time = Integer.parseInt(sc.nextLine());
                if (time != 0) break;
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid option");
            }
        }
        addController.getTaxi(fir,sec,time);
    }

    @Override
    public void showMessage(String s) {
        System.out.println(s);
    }
}
