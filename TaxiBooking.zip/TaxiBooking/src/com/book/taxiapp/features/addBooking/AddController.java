package com.book.taxiapp.features.addBooking;

public class AddController implements IAddViewController,IAddModelController{
    private final IControllerAddView addView;
    private final IControllerAddModel addModel;

    public AddController(AddView addView){
        this.addView=addView;
        addModel=new AddModel(this);
    }

    @Override
    public void getTaxi(char fir, char sec, int time) {
       addModel.getTaxi(fir,sec,time);
    }

    @Override
    public void showMessage(String s) {
        addView.showMessage(s);
    }
}
