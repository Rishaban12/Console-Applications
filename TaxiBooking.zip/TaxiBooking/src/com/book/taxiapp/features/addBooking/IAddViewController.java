package com.book.taxiapp.features.addBooking;

public interface IAddViewController {
    abstract void getTaxi(char fir, char sec, int time);
}
