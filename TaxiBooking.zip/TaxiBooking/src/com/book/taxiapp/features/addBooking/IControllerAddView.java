package com.book.taxiapp.features.addBooking;

public interface IControllerAddView {
    abstract void showMessage(String s);
}
