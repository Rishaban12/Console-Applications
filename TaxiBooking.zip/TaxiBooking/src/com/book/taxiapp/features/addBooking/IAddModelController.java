package com.book.taxiapp.features.addBooking;

public interface IAddModelController {
    abstract void showMessage(String s);
}
