package com.book.taxiapp.features.addBooking;

public interface IControllerAddModel {
    abstract void getTaxi(char fir, char sec, int time);
}
