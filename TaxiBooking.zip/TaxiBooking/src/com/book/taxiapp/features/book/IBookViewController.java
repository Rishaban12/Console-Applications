package com.book.taxiapp.features.book;

public interface IBookViewController {
    abstract void addTaxi(int opt);
}
