package com.book.taxiapp.features.book;

import com.book.taxiapp.repo.TaxiBookDb;

public class BookModel implements IControllerBookModel{
    private final IBookModelController bookController;

    public BookModel(BookController bookController){
        this.bookController=bookController;
    }

    @Override
    public void addTaxi(int opt) {
       for(int i=1;i<=opt;i++){
           TaxiBookDb.getInstance().addTaxi();
       }
    }
}
