package com.book.taxiapp.features.book;

public class BookController implements IBookViewController,IBookModelController{
    private final IControllerBookVIew bookVIew;
    private final IControllerBookModel bookModel;

    public BookController(BookView bookVIew){
        this.bookVIew=bookVIew;
        bookModel=new BookModel(this);
    }

    @Override
    public void addTaxi(int opt) {
        bookModel.addTaxi(opt);
    }
}
