package com.book.taxiapp.features.book;

import com.book.taxiapp.features.addBooking.AddView;
import com.book.taxiapp.features.show.ShowView;

import java.util.Scanner;

public class BookView implements IControllerBookVIew{
    private final IBookViewController bookController;
    private final Scanner sc;

    public BookView(){
        bookController=new BookController(this);
        sc=new Scanner(System.in);
    }

    public void initView(){
      f:  while (true){
            print();
            try {
                int opt = Integer.parseInt(sc.nextLine());

                switch (opt) {
                    case 1:
                        new AddView().bookTaxi();
                        break;
                    case 2:
                        new ShowView().viewDetails();
                        break;
                    case 3:
                        break f;
                    default:
                        System.out.println("Please provide the valid option");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid....");
            }
        }
    }

    public void taxiView(){
        int opt=0;
        while(true){
            System.out.println("How many taxi wants to run?");
            try {
                opt = Integer.parseInt(sc.nextLine());
                if (opt >= 0) break;
            } catch (NumberFormatException e) {
                System.out.println("Enter the valid number");
            }
        }
        bookController.addTaxi(opt);
        initView();
    }

    public void print(){
        System.out.println("======DashBoard======");
        System.out.println("1. Book Taxi");
        System.out.println("2. View Taxi Details");
        System.out.println("3. Exit");
        System.out.println("Choose the option(1-3)");
    }
}
