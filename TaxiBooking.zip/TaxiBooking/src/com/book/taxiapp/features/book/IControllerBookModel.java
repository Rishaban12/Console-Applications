package com.book.taxiapp.features.book;

public interface IControllerBookModel {
    abstract void addTaxi(int opt);
}
