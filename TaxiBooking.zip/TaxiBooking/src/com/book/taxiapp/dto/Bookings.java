package com.book.taxiapp.dto;

public class Bookings {
    private int bookId;
    private int cusId;
    private char from;
    private char to;
    private int pickup;


    public Bookings(int bookId,int cusId,char from,char to,int pickup) {
        this.bookId = bookId;
        this.cusId=cusId;
        this.from=from;
        this.to=to;
        this.pickup=pickup;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getCusId() {
        return cusId;
    }

    public void setCusId(int cusId) {
        this.cusId = cusId;
    }

    public char getFrom() {
        return from;
    }

    public void setFrom(char from) {
        this.from = from;
    }

    public char getTo() {
        return to;
    }

    public void setTo(char to) {
        this.to = to;
    }

    public int getPickup() {
        return pickup;
    }

    public void setPickup(int pickup) {
        this.pickup = pickup;
    }
}
