package com.book.taxiapp.dto;

import java.awt.print.Book;
import java.util.List;

public class Taxi {
    private int taxiId;
    private char curPos;
    private double earnings;
    private int time;
    private List<Bookings> bookings;

    public Taxi(int taxiId,char curPos,double earnings,List<Bookings> bookings,int time) {
        this.taxiId = taxiId;
        this.curPos=curPos;
        this.earnings=earnings;
        this.bookings=bookings;
        this.time=time;

    }

    public void setTaxiId(int taxiId){
        this.taxiId=taxiId;
    }
    public int getTaxiId(){
        return taxiId;
    }

    public char getCurPos() {
        return curPos;
    }

    public void setCurPos(char curPos) {
        this.curPos = curPos;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public List<Bookings> getBookings() {
        return bookings;
    }

  /*  public void setBookings(List<Bookings> bookings) {
        this.bookings = bookings;
    }
    */
    public void addBookings(Bookings book){
        bookings.add(book);
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }
}
