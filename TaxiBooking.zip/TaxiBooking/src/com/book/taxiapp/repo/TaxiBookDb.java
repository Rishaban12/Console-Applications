package com.book.taxiapp.repo;

import com.book.taxiapp.dto.Bookings;
import com.book.taxiapp.dto.Taxi;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TaxiBookDb {
    private static  TaxiBookDb s;
    private static List<Taxi> list;
    private static int taxiInc=0;


    public TaxiBookDb(){
        list=new ArrayList<>();
    }

    public static TaxiBookDb getInstance(){
        if(s==null){
            s=new TaxiBookDb();
        }
        return s;
    }


    public void addTaxi() {
        Taxi taxi=new Taxi(++taxiInc,'A',0.0,new ArrayList<>(),0);
        list.add(taxi);
    }


    public List<Taxi> get(){
        return list;
    }
}
