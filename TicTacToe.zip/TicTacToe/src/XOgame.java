import com.game.xoplay.features.ShowView;

public class XOgame {
    public static final String version="0.0.1";

    public static void main(String[] args) {
        XOgame xOgame=new XOgame();
        xOgame.init();
    }
    private void init(){
        System.out.println("Welcome to the TicTacToe Game "+ version);
        new ShowView().initGame();
    }
}
