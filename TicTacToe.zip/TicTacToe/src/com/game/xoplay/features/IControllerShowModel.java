package com.game.xoplay.features;

public interface IControllerShowModel {
    abstract void sendCom(char[][] arr,boolean[][] arr1);

    abstract boolean checkComputer(char[][] arr,char ch);

    abstract boolean checkBoolean(boolean[][] arr1);

    abstract void sendHum(char[][] arr, boolean[][] arr1, int row, int col);
}
