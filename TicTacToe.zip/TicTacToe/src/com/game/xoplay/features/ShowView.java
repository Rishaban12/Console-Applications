package com.game.xoplay.features;

import java.util.Scanner;

public class ShowView implements IControllerShowView{
    private final IShowViewController showController;
    private  char[][] arr=new char[0][];
    private boolean[][] arr1=new boolean[0][];
    private final Scanner sc=new Scanner(System.in);

    public ShowView(){
        showController=new ShowController(this);
    }

    public void initGame() {
        int opt=0;
        while(true){
            try {
                print();
                 opt = Integer.parseInt(sc.nextLine());
                if (opt >= 1 && opt <= 3) break;
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid option");
            }
        }
            if(opt==1) start(3);
            else if(opt==2) start(5);
            else start(7);
    }

    public void print(){
        System.out.println("1.  3×3");
        System.out.println("2.  5×5");
        System.out.println("3.  7×7");
        System.out.println("Choose the option which you want(1-3)...");
    }

    public void start(int a){
        arr=new char[a][a];
        arr1=new boolean[a][a];
        while(true) {
            printMat(arr,a);
            printOption(arr);
         //   System.out.println(len);
            int row=0;
            int col=0;
            while(true) {
                try {
                    System.out.println("Enter the correct option that you want to place the X: ");
                    System.out.println("Enter the row");
                    row = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter the column");
                    col = Integer.parseInt(sc.nextLine());
                   if(!arr1[row][col] && (row>=0 && row<a) && (col>=0 && col<a)) break;
                } catch (NumberFormatException e) {
                    System.out.println("Please provide the valid option");
                }
            }
            showController.sendHum(arr,arr1,row,col);
            if(showController.checkComputer(arr,'X')) {
                printMat(arr,a);
                System.out.println("You win");
                break;
            }
            showController.sendCom(arr,arr1);
            if(showController.checkComputer(arr,'O')){
                printMat(arr,a);
                System.out.println("System win");
                break;
            }
            else if(showController.checkBoolean(arr1)){
                printMat(arr,a);
                System.out.println("Match Draw");
                break;
            }
        }
    }

    public void printOption(char[][] arr){
        int c=1;
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr[i].length;j++){
                if((arr[i][j]!='O') && (arr[i][j]!='X')){
                    System.out.println(c++ +". Choose the position ("+i+","+j+")");
                }
            }
        }
    }

    public void printMat(char[][] arr,int a){
        System.out.println("===================================");
        for (int i = 0; i < a; i++) {
            for (int j = 0; j < a; j++) {
                System.out.print("|" + arr[i][j] + "|");
            }
            System.out.println();
        }
    }
}
