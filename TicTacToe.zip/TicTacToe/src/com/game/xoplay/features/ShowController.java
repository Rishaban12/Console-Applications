package com.game.xoplay.features;

public class ShowController implements IShowViewController,IShowModelController{
    private final IControllerShowView showView;
    private final IControllerShowModel showModel;

    public ShowController(ShowView showView){
        this.showView=showView;
        showModel=new ShowModel(this);
    }

    @Override
    public void sendCom(char[][] arr, boolean[][] arr1) {
      showModel.sendCom(arr,arr1);
    }

    @Override
    public boolean checkBoolean(boolean[][] arr1) {
        return showModel.checkBoolean(arr1);
    }

    @Override
    public void sendHum(char[][] arr, boolean[][] arr1, int row, int col) {
      showModel.sendHum(arr,arr1,row,col);
    }

    @Override
    public boolean checkComputer(char[][] arr,char ch) {
        return showModel.checkComputer(arr,ch);
    }

}
