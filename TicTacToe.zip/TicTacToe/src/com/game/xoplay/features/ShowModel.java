package com.game.xoplay.features;
import java.util.Random;

public class ShowModel implements IControllerShowModel{
    private final IShowModelController showController;
    public ShowModel(ShowController showController){
        this.showController=showController;
    }

    @Override
    public void sendHum(char[][] arr,boolean[][] arr1,int a,int b) {
        if (arr1[a][b]) {return;}
            arr[a][b] = 'X';
            arr1[a][b] = true;
    }

    @Override
    public void sendCom(char[][] arr, boolean[][] arr1) {
        Random rand=new Random();
        while(true) {
            int row = rand.nextInt(arr.length);
            int col = rand.nextInt(arr.length);
            if (!arr1[row][col]) {
                arr[row][col] = 'O';
                break;
            }
        }
    }
    //win check
    public boolean checkComputer(char[][] arr,char ch){
        int count=0; //firstcross
        for(int i=0;i<arr.length;i++){
            if(arr[i][i]==ch) count++;
        }
        if(count>= arr.length) return true;

        count=0;//vertically
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr.length;j++) {
                if (arr[j][i] == ch) count++;
            }
            if(count>= arr.length) return true;
            count=0;
        }
        count=0;
        //horizontally
        for(int i=0;i<arr.length;i++){
            for(int j=0;j<arr.length;j++) {
                if (arr[i][j] == ch) count++;
            }
            if(count>= arr.length) return true;
            count=0;
        }
        count=0;
        //reverse cross
        for(int i=0,j=arr.length-1;i<arr.length && j>=0;i++,j--){
            if(arr[i][j]==ch) count++;
        }
        if(count>= arr.length) return true;
        return false;
    }
    //draw check
    public boolean checkBoolean(boolean[][] arr1){
        for (boolean[] booleans : arr1) {
            for (int j = 0; j < booleans.length; j++) {
                if (!booleans[j]) {
                    return false;
                }
            }
        }
        return true;
    }
}
