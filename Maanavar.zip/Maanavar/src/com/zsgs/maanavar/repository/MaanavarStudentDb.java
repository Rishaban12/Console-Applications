package com.zsgs.maanavar.repository;

import com.zsgs.maanavar.dto.Attendance;
import com.zsgs.maanavar.dto.IDidThis;
import com.zsgs.maanavar.dto.StudentFeedback;

import java.util.ArrayList;
import java.util.List;

public class MaanavarStudentDb {
    private static MaanavarStudentDb s=null;
    List<Attendance> attendanceList=new ArrayList<>();
    List<StudentFeedback> studentFeedbacks=new ArrayList<>();
    List<IDidThis> iDidThis=new ArrayList<>();
    private MaanavarStudentDb(){}
    public static MaanavarStudentDb getInstance(){
        if(s==null){
            s=new MaanavarStudentDb();
        }
        return s;
    }

    public void putAttendance(Attendance attendance) {
        attendanceList.add(attendance);
    }

    public List<Attendance> seeAttendance() {
        return attendanceList;
    }

    public void putFeedback(StudentFeedback studentFeedback) {
        studentFeedbacks.add(studentFeedback);
    }

    public List<StudentFeedback> getFeedback() {
        return studentFeedbacks;
    }

    public void iDidThis(IDidThis list) {
        iDidThis.add(list);
    }

    public List<IDidThis> viewIDidThis() {
        return iDidThis;
    }
}
