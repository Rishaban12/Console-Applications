package com.zsgs.maanavar.repository;

import com.zsgs.maanavar.dto.ScheduleInfo;
import com.zsgs.maanavar.dto.TaskStatus;
import com.zsgs.maanavar.dto.Tasks;

import java.util.ArrayList;
import java.util.List;

public class MaanavarFacultyDb {
    List<ScheduleInfo> scheduleInfos=new ArrayList<>();
    List<Tasks> list=new ArrayList<>();
    List<TaskStatus> taskStatuses=new ArrayList<>();

    private static MaanavarFacultyDb s=null;
    private MaanavarFacultyDb(){}
    public static MaanavarFacultyDb getInstance(){
        if(s==null){
            s=new MaanavarFacultyDb();
        }
        return s;
    }


    public void putSchedule(ScheduleInfo scheduleInfo) {
        scheduleInfos.add(scheduleInfo);
    }

    public List<ScheduleInfo> showSchedule() {
        return scheduleInfos;
    }

    public void addTask(Tasks task) {
        list.add(task);
    }

    public List<Tasks> seeTask() {
        return list;
    }

    public void addTaskStatus(TaskStatus taskStatus) {
        taskStatuses.add(taskStatus);
    }

    public List<TaskStatus> taskStatusView() {
        return taskStatuses;
    }
}
