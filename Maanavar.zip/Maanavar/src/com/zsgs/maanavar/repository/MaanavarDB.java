package com.zsgs.maanavar.repository;

import com.zsgs.maanavar.dto.FacultyInfo;
import com.zsgs.maanavar.dto.LoginCredentials;
import com.zsgs.maanavar.dto.StudentInfo;
import com.zsgs.maanavar.dto.SubjectInfo;
import com.zsgs.maanavar.util.UserRole;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MaanavarDB {
  private static MaanavarDB s=null; //static--> like immutable (once obj create ana create aanadhu dhan)
  private static final List<StudentInfo> studentList=new ArrayList<>();
  private static final List<FacultyInfo> facultyList=new ArrayList<>();

   private static final List<SubjectInfo> subject=new ArrayList<>( Arrays.asList(
           new SubjectInfo("TAM01", "Tamil", "Theory"),
           new SubjectInfo("ENG01", "English", "Theory"),
           new SubjectInfo("CS01", "Java", "Practical"),
           new SubjectInfo("SO08", "Social", "Theory"),
           new SubjectInfo("SC09", "Science", "Practical")
           ));

    private MaanavarDB(){
    }  //velilendu access pannamudiyathu neraiya instance create pannamudiyathu why private const? to avoid of so many obj creation and avoid of memory waste

    public static MaanavarDB getInstance(){
        if(s==null){
            s=new MaanavarDB();
        }
        return s;
    }

    private final LoginCredentials credentials=new LoginCredentials("1","admin","ZSGS");
    private final LoginCredentials faculty=new LoginCredentials("2","faculty","ZSGS");
    private final LoginCredentials student=new LoginCredentials("3","student","ZSGS");

    private boolean firstTimeLogin=true;

    public void insertStudent(StudentInfo student){
        //insert query
        studentList.add(student);
    }
    public List<StudentInfo> showStudents(){
        return studentList;
    }

    public void insertFaculty(FacultyInfo faculty){
        //insert query;
        facultyList.add(faculty);
    }
    public void updatePassword(String newPassword){
        credentials.setPassword(newPassword);
        firstTimeLogin=false;
    }
    public UserRole isValidUser(String userName, String password) {

        if(userName.equals(credentials.getUserName()) && password.equals(credentials.getPassword())){
            return UserRole.ADMIN;
        }
        if( userName.equals(faculty.getUserName()) && password.equals(faculty.getPassword())) {
            return UserRole.FACULTY;
        }
        if(userName.equals(student.getUserName()) && password.equals(student.getPassword())){
            return UserRole.STUDENT;
        }
        return UserRole.INVALID;
    }

    public boolean onFirstTimeLogin() {
        return firstTimeLogin;
    }
   public StudentInfo getStudent(String studentId){
        return new StudentInfo();
    }

    public List<FacultyInfo> showFaculty() {
        return facultyList;
    }

    public List<SubjectInfo> seeSubject() {
        return subject;
    }
}
