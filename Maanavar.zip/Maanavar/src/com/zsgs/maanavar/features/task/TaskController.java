package com.zsgs.maanavar.features.task;

import com.zsgs.maanavar.dto.TaskStatus;
import com.zsgs.maanavar.dto.Tasks;

import java.util.Collections;
import java.util.List;

public class TaskController implements IControllerTaskView,IControllerTaskModel{
    private final ITaskViewController taskView;
    private final ITaskModelController taskModel;

    public TaskController(TaskView taskView){
       this.taskView=taskView;
       taskModel=new TaskModel(this);
    }

    @Override
    public void addTask(Tasks task) {
        taskModel.addTask(task);
    }

    @Override
    public List<Tasks> seeTask() {
        return taskModel.seeTask();
    }

    @Override
    public void addTaskStatus(TaskStatus taskStatus) {
        taskModel.addTaskStatus(taskStatus);
    }

    @Override
    public List<TaskStatus> taskStatusView() {
        return taskModel.taskStatusView();
    }
}
