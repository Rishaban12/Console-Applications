package com.zsgs.maanavar.features.task;

public interface IControllerTaskModel {
}
