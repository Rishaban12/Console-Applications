package com.zsgs.maanavar.features.task;

import com.zsgs.maanavar.dto.TaskStatus;
import com.zsgs.maanavar.dto.Tasks;

import java.util.List;

public interface IControllerTaskView {
    abstract void addTask(Tasks task);

    abstract List<Tasks> seeTask();

    abstract void addTaskStatus(TaskStatus taskStatus);

    abstract List<TaskStatus> taskStatusView();
}
