package com.zsgs.maanavar.features.task;

import com.zsgs.maanavar.dto.TaskStatus;
import com.zsgs.maanavar.dto.Tasks;
import com.zsgs.maanavar.repository.MaanavarFacultyDb;

import java.util.Collections;
import java.util.List;

public class TaskModel implements ITaskModelController {
    private final IControllerTaskModel taskController;

    public TaskModel(TaskController taskController) {
        this.taskController=taskController;
    }

    @Override
    public void addTask(Tasks task) {
        MaanavarFacultyDb.getInstance().addTask(task);
    }

    @Override
    public List<Tasks> seeTask() {
        return MaanavarFacultyDb.getInstance().seeTask();
    }

    @Override
    public void addTaskStatus(TaskStatus taskStatus) {
        MaanavarFacultyDb.getInstance().addTaskStatus(taskStatus);
    }

    @Override
    public List<TaskStatus> taskStatusView() {
        return MaanavarFacultyDb.getInstance().taskStatusView();
    }
}
