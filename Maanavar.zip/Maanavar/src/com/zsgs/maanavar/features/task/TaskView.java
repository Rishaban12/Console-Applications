package com.zsgs.maanavar.features.task;

import com.zsgs.maanavar.dto.TaskStatus;
import com.zsgs.maanavar.dto.Tasks;

import java.util.List;
import java.util.Scanner;

public class TaskView implements ITaskViewController{
    private final IControllerTaskView taskController;
    private final Scanner sc=new Scanner(System.in);

    public TaskView(){
        taskController=new TaskController(this);
    }

    public void putTask() {
        System.out.println("=====Add the task====");
        System.out.println("Enter the Task Id");
        int taskId=sc.nextInt();
        System.out.println("Enter the subjectCode");
        String code=sc.next();
        System.out.println("Enter the FacultyId");
        String facultyId=sc.next();
        System.out.println("Enter the Task Description");
        String taskDes=sc.next();
        System.out.println("Enter the given Date");
        String givenDate=sc.next();
        System.out.println("Enter the Deadline");
        String deadline=sc.next();

        Tasks task=new Tasks(taskId,code,facultyId,taskDes,givenDate,deadline);

        taskController.addTask(task);
    }
    public void seeTask() {
        List<Tasks> li=taskController.seeTask();
        if(li.isEmpty()){
            System.out.println("Task is not given yet");
        }
        System.out.println("======Task Details=====");
        for(Tasks s: li){
            System.out.println("Task Id: "+s.getTaskId()+
                    "Subject Code: "+ s.getSubjectCode()+
                    "Faculty Id: "+s.getFacultyId()+
                    "Task Description: "+s.getTaskDesc()+
                    "Given Date: "+s.getGivenDate()+
                    "Deadline: "+s.getDeadline()+
                    "-------------------------------");
        }
        System.out.println("==========================");
    }

    public void addTaskStatus() {
        System.out.println("Add the Task Status Details");
        System.out.println("Enter the Task Status Id");
        int taskStatusId=sc.nextInt();
        System.out.println("Enter the Task Id");
        int taskId=sc.nextInt();
        System.out.println("Enter the StudentId");
        String StudentId=sc.next();
        System.out.println("Enter the Task");
        String task=sc.next();
        System.out.println("Completion status");
        String complete=sc.next();
        System.out.println("Enter the review");
        String review=sc.next();
        System.out.println("Enter the reviewedFacultyId");
        String reviewFacultyId=sc.next();

        TaskStatus taskStatus=new TaskStatus(taskStatusId,taskId,StudentId,task,complete,review,reviewFacultyId);

        taskController.addTaskStatus(taskStatus);
    }

    public void taskStatusView(){
        List<TaskStatus> task=taskController.taskStatusView();
    }
}

