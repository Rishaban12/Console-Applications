package com.zsgs.maanavar.features.schedule;

import com.zsgs.maanavar.dto.ScheduleInfo;
import com.zsgs.maanavar.dto.Slot;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ScheduleView implements IScheduleViewController{
    
    private final IControllerScheduleView scheduleController;
    private final Scanner sc=new Scanner(System.in);
    
    public ScheduleView(){
        scheduleController=new ScheduleController(this);
    }

    public void showFacultyList() {

    }
    public void putSchedule(){
        System.out.println("Enter the Scheduling Details");

        System.out.println("Enter the first slot");

            System.out.println("Enter the start time");
            String st1 = sc.next();
            System.out.println("Enter the end time");
            String st2 = sc.next();
            Slot slot1 = new Slot(st1, st2);

        System.out.println("Enter the first slot");

        System.out.println("Enter the start time");
        String st3 = sc.next();
        System.out.println("Enter the end time");
        String st4 = sc.next();
        Slot slot2 = new Slot(st3, st4);


        System.out.println("Enter the Practical Date");
        String date=sc.next();
        System.out.println("Enter the subjectId");
        String id=sc.next();

        ScheduleInfo scheduleInfo=new ScheduleInfo(slot1,slot2,date,id);
        scheduleController.putSchedule(scheduleInfo);
    }

    public void showSchedule() {
        List<ScheduleInfo> list=scheduleController.showSchedule();

        if(list.isEmpty()){
            System.out.println("Schedule is Empty");
        }
        System.out.println("======Schedule Details=====");

        for(ScheduleInfo x: list){
            System.out.println("Slot1: "+x.getSlot1()+"\n"+"Slot2: "+x.getSlot2()+
                    "Practical Date: "+x.getDate()+
                    "Subject Id: "+x.getScheduleId()+"\n"+
                    "-----------------------------------");
        }
        System.out.println("============================");
    }

}
