package com.zsgs.maanavar.features.schedule;

import com.zsgs.maanavar.dto.ScheduleInfo;

import java.util.Collections;
import java.util.List;

public class ScheduleController implements IControllerScheduleView,IControllerScheduleModel{
    private final IScheduleViewController scheduleView;
    private final IScheduleModelController scheduleModel;

    public ScheduleController(ScheduleView scheduleView){
        this.scheduleView=scheduleView;
        scheduleModel=new ScheduleModel(this);
    }

    @Override
    public void putSchedule(ScheduleInfo scheduleInfo) {
        scheduleModel.putSchedule(scheduleInfo);
    }

    @Override
    public List<ScheduleInfo> showSchedule() {
        return scheduleModel.showSchedule();
    }
}
