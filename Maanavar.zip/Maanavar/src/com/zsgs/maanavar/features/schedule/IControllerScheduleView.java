package com.zsgs.maanavar.features.schedule;

import com.zsgs.maanavar.dto.ScheduleInfo;

import java.util.List;

public interface IControllerScheduleView {
    abstract void putSchedule(ScheduleInfo scheduleInfo);

   abstract List<ScheduleInfo> showSchedule();
}
