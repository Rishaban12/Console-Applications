package com.zsgs.maanavar.features.schedule;

public interface IControllerScheduleModel {
}
