package com.zsgs.maanavar.features.schedule;

import com.zsgs.maanavar.dto.FacultyInfo;
import com.zsgs.maanavar.dto.ScheduleInfo;
import com.zsgs.maanavar.repository.MaanavarFacultyDb;

import java.util.List;

public class ScheduleModel implements IScheduleModelController{

    private final IControllerScheduleModel scheduleController;

    public ScheduleModel(ScheduleController scheduleController){
        this.scheduleController= scheduleController;
    }


    @Override
    public void putSchedule(ScheduleInfo scheduleInfo) {
        MaanavarFacultyDb.getInstance().putSchedule(scheduleInfo);
    }

    public List<ScheduleInfo> showSchedule(){
        return MaanavarFacultyDb.getInstance().showSchedule();
    }
}
