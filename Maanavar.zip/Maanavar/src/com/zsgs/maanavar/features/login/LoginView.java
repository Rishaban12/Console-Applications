package com.zsgs.maanavar.features.login;

import com.zsgs.maanavar.features.dashboard.AdminDashboardView;
import com.zsgs.maanavar.features.dashboard.FacultyDashBoardView;
import com.zsgs.maanavar.features.dashboard.StudentDashBoardView;
import com.zsgs.maanavar.features.updatecredentials.UpdateCredentialsView;
import com.zsgs.maanavar.util.UserRole;

import java.util.Scanner;

public class LoginView implements ILoginControllerView{
  //private final LoginModel loginModel;

    private final ILoginViewController loginController;

    public LoginView(){
        //loginModel=new LoginModel(this);
        loginController=new LoginController(this);
    }
    public void initLogin(){

        // view logic
        System.out.println("Enter the userName: ");
        Scanner sc=new Scanner(System.in);
        String userName=sc.next();
        System.out.println("Enter the password: ");
        String password=sc.next();
        //checking logic

        //business logic
        /*if(*//*data access logic*//*new MaanavarDB().isValidUser(userName,password)) {
            UpdateCredentials updateCredentials = new UpdateCredentials();
            updateCredentials.init();
        } else{
            System.out.println("Invalid password or UserName");
            System.out.println("Do you want to try again? Y/N");
            String option = sc.next();
            if(option.equals("Y")){
                initLogin();
            }
        }*///move this to the model

        loginController.validateCredentials(userName,password);
    }
    public void onLoginSuccess(UserRole role) {
        System.out.println("Successfully login");

        switch (role){
            case ADMIN:
              new AdminDashboardView().showDashBoard();
              break;
            case FACULTY:
                new FacultyDashBoardView().showDashBoard();
                break;
            case STUDENT:
                new StudentDashBoardView().showDashBoard();
                break;
    }
    }

    public void onLoginFailed() {
        System.out.println("Invalid password or UserName");
        System.out.println("Do you want to try again? Y/N");
        Scanner sc=new Scanner(System.in);
        String option = sc.next();
        if(option.equals("Y")){
            initLogin();
        }
    }
    public void onFirstTimeLogin() {
        System.out.println("You are logging in for the first time.");
        UpdateCredentialsView updateCredentialsView = new UpdateCredentialsView();
        updateCredentialsView.changePassword();
        onLoginSuccess(UserRole.ADMIN);
    }
}
