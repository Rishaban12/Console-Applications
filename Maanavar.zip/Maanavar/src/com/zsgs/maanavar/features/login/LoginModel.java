package com.zsgs.maanavar.features.login;

import com.zsgs.maanavar.repository.MaanavarDB;
import com.zsgs.maanavar.util.UserRole;

public class LoginModel implements ILoginControllerModel {
    private ILoginModelController loginController;


    public LoginModel(LoginController loginController) {
        this.loginController = loginController;  //login view nu erkanavey app la instance create aagitu so used that same instance by the pass of loginModel const(loginview oda reference pass)
    }

    public void validateCredentials(String userName, String password) {
        /*data access logic*/
        UserRole role = MaanavarDB.getInstance().isValidUser(userName, password);
        if (role == UserRole.ADMIN) {
            if (MaanavarDB.getInstance().onFirstTimeLogin()) {
                loginController.onFirstTimeLogin();
            } else {
                loginController.onLoginSuccess(role);
            }
        } else if (role == UserRole.FACULTY || role == UserRole.STUDENT) {
            loginController.onLoginSuccess(role);
        } else {
            loginController.onLoginFailed();
        }
    }
}

