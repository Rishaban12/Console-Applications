package com.zsgs.maanavar.features.login;

import com.zsgs.maanavar.util.UserRole;

public class LoginController implements ILoginViewController,ILoginModelController {   //low level classes (It avoids tight coupling) --> one class is depends on other. it makes problem when update
   private final ILoginControllerView loginView; // high level classes
   private final ILoginControllerModel loginModel;

    public LoginController(LoginView loginView) {
         this.loginView =loginView;
         loginModel=new LoginModel(this);
    }

    public void validateCredentials(String userName, String password) {
        loginModel.validateCredentials(userName,password);
    }

    public void onFirstTimeLogin(){
        loginView.onFirstTimeLogin();
    }
    public void onLoginSuccess(UserRole role) {
        loginView.onLoginSuccess(role);
    }

    public void onLoginFailed() {
        loginView.onLoginFailed();
    }
}
