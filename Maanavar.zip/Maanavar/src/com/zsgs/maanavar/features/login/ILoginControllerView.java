package com.zsgs.maanavar.features.login;

import com.zsgs.maanavar.util.UserRole;

public interface ILoginControllerView {
    void onFirstTimeLogin();

    void onLoginSuccess(UserRole role);

    void onLoginFailed();
}
