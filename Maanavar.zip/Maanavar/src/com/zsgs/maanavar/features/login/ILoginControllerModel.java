package com.zsgs.maanavar.features.login;

public interface ILoginControllerModel {
    void validateCredentials(String userName, String password);
}
