package com.zsgs.maanavar.features.login;

public interface ILoginViewController {
    void validateCredentials(String userName, String password);
}
