package com.zsgs.maanavar.features.manageAdmin;

import com.zsgs.maanavar.dto.FacultyInfo;
import com.zsgs.maanavar.dto.StudentInfo;
import com.zsgs.maanavar.repository.MaanavarDB;

import java.util.List;

public class ManageModel implements IManageModelController{

    private final IControllerManageModel manageController;

    public ManageModel(ManageController manageController){
        this.manageController=manageController;
    }

    public void addFaculty(FacultyInfo facultyInfo){
        MaanavarDB.getInstance().insertFaculty(facultyInfo);
        manageController.onFacultyAdded();
    }

    public void addStudent(StudentInfo studentInfo){
        MaanavarDB.getInstance().insertStudent(studentInfo);
        manageController.onStudentAdded();
    }

    public List<StudentInfo> getStudent(){
        return MaanavarDB.getInstance().showStudents();
    }

    @Override
    public List<FacultyInfo> getFaculty() {
        return MaanavarDB.getInstance().showFaculty();
    }
}
