package com.zsgs.maanavar.features.manageAdmin;

import com.zsgs.maanavar.dto.FacultyInfo;
import com.zsgs.maanavar.dto.StudentInfo;

import java.util.List;

public class ManageController implements IControllerManageView,IControllerManageModel{

    private final IManageViewController manageView;
    private final IManageModelController manageModel;
    public ManageController(ManageView manageView){
        this.manageView=manageView;
        manageModel=new ManageModel(this);
    }

    public void addStudent(StudentInfo studentInfo){
        manageModel.addStudent(studentInfo);
    }

    @Override
    public void onFacultyAdded() {
        manageView.onFacultyAdded();
    }

    @Override
    public void onStudentAdded() {
        manageView.onStudentAdded();
    }

    @Override
    public List<StudentInfo> getStudent() {
       return manageModel.getStudent();
    }

    @Override
    public void addFaculty(FacultyInfo facultyInfo) {
        manageModel.addFaculty(facultyInfo);
    }

    @Override
    public List<FacultyInfo> getFaculty() {
        return manageModel.getFaculty();
    }
}
