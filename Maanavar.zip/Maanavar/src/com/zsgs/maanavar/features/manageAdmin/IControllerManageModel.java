package com.zsgs.maanavar.features.manageAdmin;

public interface IControllerManageModel {
    abstract void onFacultyAdded();

    abstract void onStudentAdded();
}
