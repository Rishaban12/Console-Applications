package com.zsgs.maanavar.features.manageAdmin;

import com.zsgs.maanavar.dto.FacultyInfo;
import com.zsgs.maanavar.dto.StudentInfo;

import java.util.List;

public interface IManageModelController {
   abstract void addStudent(StudentInfo studentInfo);
    abstract List<StudentInfo> getStudent();
    abstract void addFaculty(FacultyInfo facultyInfo);

    abstract List<FacultyInfo> getFaculty();
}
