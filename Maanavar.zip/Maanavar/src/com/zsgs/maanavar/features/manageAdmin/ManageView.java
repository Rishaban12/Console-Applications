package com.zsgs.maanavar.features.manageAdmin;

import com.zsgs.maanavar.dto.FacultyInfo;
import com.zsgs.maanavar.dto.StudentInfo;
import com.zsgs.maanavar.dto.SubjectInfo;
import com.zsgs.maanavar.features.dashboard.AdminDashboardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ManageView implements IManageViewController{
    private final AdminDashboardView adminDashboardView;
    private final IControllerManageView manageController ;
    Scanner sc=new Scanner(System.in);
    
    public ManageView(AdminDashboardView adminDashboardView){
           this.adminDashboardView = adminDashboardView;
        this.manageController=new ManageController(this);
    }

    public void showAddStudentForm() {
        System.out.println("Student Details");

        System.out.println("Enter Student Name: ");
        String name=sc.next();
        System.out.println("Enter Student Mail: ");
        String mail=sc.next();
        System.out.println("Enter Student ContactNo: ");
        String contactNo=sc.next();
        System.out.println("Enter Student RollNo: ");
        String rollNo=sc.next();
        System.out.println("Enter Student Dept: ");
        String dept=sc.next();

        StudentInfo studentInfo=new StudentInfo(name,mail,contactNo,rollNo,dept);
        manageController.addStudent(studentInfo);
    }

    public void showStudentDetails() {
        List<StudentInfo> st=manageController.getStudent();

       if(st.isEmpty()){
           System.out.println("Student Details is Empty");
           return;
       }
        System.out.println("======Student Details======");

       for(StudentInfo s: st){
           System.out.println("Student Name: "+s.getName()+"\n"+
                   "Student RollNo: "+s.getRollNo()+"\n"+
                   "Student Dept: "+s.getDept()+"\n"+
                   "Student ContactNo: "+s.getContactNo()+"\n"+
                   "Student Mail: "+s.getMailId()+"\n"+
                   "---------------------------------------");
       }
        System.out.println("==========================");
    }

    public void showAddFacultyForm() {
        System.out.println("Facutly Details");

        System.out.println("Enter Student FacultyId: ");
        String id=sc.next();
        System.out.println("Enter Student FacultyName: ");
        String facultyName=sc.next();
        System.out.println("What are the subject do you take: ");
        List<SubjectInfo> subjectInfos=new ArrayList<>();
        System.out.println("Enter the Subject Code");
        String code=sc.next();
        System.out.println("Enter the Subject Name");
        String subName=sc.next();
        System.out.println("Enter the type(Practical or Theory)");
        String subType=sc.next();
        SubjectInfo subjectInfo=new SubjectInfo(code,subName,subType);
        subjectInfos.add(subjectInfo);
        System.out.println("Enter Faculty email: ");
        String email=sc.next();
        System.out.println("Enter Faculty ContactNo: ");
        String contactNo=sc.next();

        FacultyInfo facultyInfo=new FacultyInfo(id,facultyName,subjectInfos,email,contactNo);

        manageController.addFaculty(facultyInfo);
    }

    public void showFacultyList() {
        List<FacultyInfo> faculty=manageController.getFaculty();

        if(faculty.isEmpty()){
            System.out.println("Faculty Details is Empty");
        }

        System.out.println("=========Faculty Details==========");

        for(FacultyInfo f: faculty) {
            System.out.println("Enter the faculty Name: " + f.getName() + "\n" +
                    "Enter the faculty Id: " + f.getEmpId() + "\n" +
                    "Enter the email: " + f.getEmail() + "\n" +
                    "Enter the contactNo: " + f.getContactNo() + "\n" +
                    "Enter the Subjects taken by him: " + f.getSubjects()+"\n"+
                    "---------------------------------------------------");

        }
        System.out.println("==================================");
    }

    public void onStudentAdded() {
        System.out.println("Successfully Added");
    }
    public void onFacultyAdded() {
        System.out.println("Successfully Added");
    }
}
