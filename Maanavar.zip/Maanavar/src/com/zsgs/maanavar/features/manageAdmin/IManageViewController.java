package com.zsgs.maanavar.features.manageAdmin;

public interface IManageViewController {
    abstract void onFacultyAdded();
    abstract void onStudentAdded();


}
