package com.zsgs.maanavar.features.manageStudents;

import com.zsgs.maanavar.dto.*;

import java.util.List;
import java.util.Scanner;

public class ManageStudentView implements IManageStudentVController{
    private final IControllerManageStudentV manageStudentController;
    Scanner sc=new Scanner(System.in);
//    private final StudentDashBoardView studentDashBoardView;
    public ManageStudentView(){
        manageStudentController=new ManageStudentController(this);
//        this.studentDashBoardView=studentDashBoardView;
    }

    public void putAttendance() {
        System.out.println("====Add the Attendance Details====");
        System.out.println("Enter Student AttendanceId: ");
        int attendanceId=sc.nextInt();
        System.out.println("Enter Student StudentId: ");
        String studentId=sc.next();
        System.out.println("Enter the Subject Id");
        String subjectId=sc.next();
        System.out.println("Enter the date");
        String date=sc.next();
        System.out.println("Enter the status(Present/Absent)");
        String status=sc.next();
        System.out.println("Enter the recordedId: ");
        String recordId=sc.next();

        Attendance attendance=new Attendance(attendanceId,studentId,subjectId,date,status,recordId);

        manageStudentController.putAttendance(attendance);

    }

    public void seeAttendance() {
        List<Attendance> list=manageStudentController.seeAttendance();
        if(list.isEmpty()){
            System.out.println("Attendance is empty");
        }
        System.out.println("======Attendance Details=====");
        for(Attendance s: list){
            System.out.println("Attendance Id: "+s.getAttendanceId()+
                    "Student Id "+ s.getStudentId()+
                    "Subject Id: "+s.getSubjectId()+
                    "Date: "+s.getDate()+
                    "Status: "+s.getStatus()+
                    "Recorded Id: "+s.getRecordedAt()+
                    "-------------------------------");
        }
        System.out.println("==========================");
    }

    public void iDidThis() {
        System.out.println("====Note down(TO-DO-LIST)====");
        System.out.println("Enter the StudentId: ");
        String studentId=sc.next();
        System.out.println("Enter the Date");
        String date=sc.next();
        System.out.println("Enter the Description");
        String desc=sc.next();

        IDidThis iDidThis=new IDidThis(studentId,date,desc);

        manageStudentController.iDidThis(iDidThis);
    }
    public void viewIDidThis(){
        List<IDidThis> list=manageStudentController.viewIDidThis();
        if(list.isEmpty()){
            System.out.println("IDidThis is empty");
        }
        System.out.println("======Feedback Details=====");
        for(IDidThis s: list){
            System.out.println("Student Id: "+s.getStudentId()+
                    "Date "+ s.getDate()+
                    "Description: "+s.getDescription()+
                    "-------------------------------");
        }
        System.out.println("==========================");
    }


    public void putFeedback(){
        System.out.println("====Give the Feedback====");
        System.out.println("Enter the StudentId: ");
        String studentId=sc.next();
        System.out.println("Enter the FacultyId: ");
        String facultyId=sc.next();
        System.out.println("Enter the Subject Code");
        String subjectCode=sc.next();
        System.out.println("Enter the feedback");
        String feedback=sc.next();
        System.out.println("Enter the time");
        String time=sc.next();

        StudentFeedback studentFeedback=new StudentFeedback(studentId,facultyId,subjectCode,feedback,time);

        manageStudentController.putFeedback(studentFeedback);

    }

    public void getFeedback() {
        List<StudentFeedback> list=manageStudentController.getFeedback();
        if(list.isEmpty()){
            System.out.println("Feedback is empty");
        }
        System.out.println("======Feedback Details=====");
        for(StudentFeedback s: list){
            System.out.println("Student Id: "+s.getStudentId()+
                    "Faculty Id "+ s.getFacultyId()+
                    "Subject Code: "+s.getSubjectCode()+
                    "Feedback: "+s.getFeedback()+
                    "Time: "+s.getTime()+
                    "-------------------------------");
        }
        System.out.println("==========================");
    }

    }


