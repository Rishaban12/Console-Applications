package com.zsgs.maanavar.features.manageStudents;

import com.zsgs.maanavar.dto.Attendance;
import com.zsgs.maanavar.dto.IDidThis;
import com.zsgs.maanavar.dto.StudentFeedback;

import java.util.List;

public interface IControllerManageStudentV {
    abstract void putAttendance(Attendance attendance);

    abstract List<Attendance> seeAttendance();

    abstract void putFeedback(StudentFeedback studentFeedback);

    abstract List<StudentFeedback> getFeedback();

    abstract void iDidThis(IDidThis iDidThis);

    abstract List<IDidThis> viewIDidThis();
}
