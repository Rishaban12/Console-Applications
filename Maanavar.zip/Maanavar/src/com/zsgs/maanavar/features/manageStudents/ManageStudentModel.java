package com.zsgs.maanavar.features.manageStudents;

import com.zsgs.maanavar.dto.Attendance;
import com.zsgs.maanavar.dto.IDidThis;
import com.zsgs.maanavar.dto.StudentFeedback;
import com.zsgs.maanavar.repository.MaanavarStudentDb;

import java.util.List;

public class ManageStudentModel implements IManageMController{
    private final IControllerManageM manageStudentController;


    public ManageStudentModel(ManageStudentController manageStudentController){
        this.manageStudentController=manageStudentController;
    }

    @Override
    public void putAttendance(Attendance attendance) {
        MaanavarStudentDb.getInstance().putAttendance(attendance);
    }

    @Override
    public List<Attendance> seeAttendance() {
        return MaanavarStudentDb.getInstance().seeAttendance();
    }

    @Override
    public void putFeedback(StudentFeedback studentFeedback) {
        MaanavarStudentDb.getInstance().putFeedback(studentFeedback);
    }

    @Override
    public List<StudentFeedback> getFeedback() {
        return MaanavarStudentDb.getInstance().getFeedback();
    }

    @Override
    public void iDidThis(IDidThis iDidThis) {
        MaanavarStudentDb.getInstance().iDidThis(iDidThis);
    }

    @Override
    public List<IDidThis> viewIDidThis() {
        return MaanavarStudentDb.getInstance().viewIDidThis();
    }
}
