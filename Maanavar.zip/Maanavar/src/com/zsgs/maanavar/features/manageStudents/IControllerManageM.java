package com.zsgs.maanavar.features.manageStudents;

public interface IControllerManageM {
}
