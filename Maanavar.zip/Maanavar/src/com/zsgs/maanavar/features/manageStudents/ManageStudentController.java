package com.zsgs.maanavar.features.manageStudents;

import com.zsgs.maanavar.dto.Attendance;
import com.zsgs.maanavar.dto.IDidThis;
import com.zsgs.maanavar.dto.StudentFeedback;

import java.util.List;

public class ManageStudentController implements IControllerManageStudentV,IControllerManageM{
    private final IManageStudentVController manageStudentView;
    private final IManageMController manageStudentModel;
    
    public ManageStudentController(ManageStudentView manageStudentView){
        this.manageStudentView=manageStudentView;
        manageStudentModel=new ManageStudentModel(this);
    }

    @Override
    public void putAttendance(Attendance attendance) {
        manageStudentModel.putAttendance(attendance);
    }

    @Override
    public List<Attendance> seeAttendance() {
        return manageStudentModel.seeAttendance();
    }

    @Override
    public void putFeedback(StudentFeedback studentFeedback) {
        manageStudentModel.putFeedback(studentFeedback);
    }

    @Override
    public List<StudentFeedback> getFeedback() {
        return manageStudentModel.getFeedback();
    }

    @Override
    public void iDidThis(IDidThis iDidThis) {
        manageStudentModel.iDidThis(iDidThis);
    }

    @Override
    public List<IDidThis> viewIDidThis() {
        return manageStudentModel.viewIDidThis();
    }
}
