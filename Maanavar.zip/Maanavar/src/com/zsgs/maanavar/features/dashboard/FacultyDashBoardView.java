package com.zsgs.maanavar.features.dashboard;

import com.zsgs.maanavar.features.login.LoginView;
import com.zsgs.maanavar.features.schedule.ScheduleView;
import com.zsgs.maanavar.features.subject.SubjectView;
import com.zsgs.maanavar.features.task.TaskView;
import com.zsgs.maanavar.features.manageStudents.ManageStudentView;

import java.util.Scanner;

public class FacultyDashBoardView {
    private final Scanner sc=new Scanner(System.in);
    private final ManageStudentView manageStudentView;
    private final SubjectView subjectView;
    private final TaskView taskView;
    private final ScheduleView scheduleView;

    public FacultyDashBoardView(){
        manageStudentView=new ManageStudentView();
        subjectView=new SubjectView();
        taskView=new TaskView();
        scheduleView=new ScheduleView();
    }
    public void showDashBoard() {
        printMenu();
        boolean run = true;
        System.out.println("Choose the option (1-7): ");
        while (run) {
            int option = sc.nextInt();

            switch (option) {
                case 1:
                    scheduleView.putSchedule();
                    break;
                case 2:
                    subjectView.seeSubject();
                    break;
                case 3:
                    taskView.putTask();
                    break;
                case 4:
                    manageStudentView.getFeedback();
                    break;
                case 5:
                    manageStudentView.putAttendance();
                    break;
                case 6:
                    taskView.addTaskStatus();
                    break;
                case 7:
                    System.out.println("System is logging out.....");
                    run = false;
                    break;
                default:
                    System.out.println("Please give a valid option");
            }
        }
        System.out.println("Do you want to login again (Y/N): ");
        String op = sc.next();
        if (op.equals("Y")) {
            new LoginView().initLogin();
        } else {
            System.out.println("Thank you for using the app");
        }
    }
    public void printMenu(){
        System.out.println("===Faculty Portal===");
        System.out.println("1. See the Schedule");
        System.out.println("2. Subject Info");
        System.out.println("3. Task Assign");
        System.out.println("4. View Student feedback");
        System.out.println("5. Attendance");
        System.out.println("6. Add Task Status");
        System.out.println("7. Logout");
    }
}
