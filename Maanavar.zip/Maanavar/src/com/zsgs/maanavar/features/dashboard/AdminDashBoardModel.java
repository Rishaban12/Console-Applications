package com.zsgs.maanavar.features.dashboard;

public class AdminDashBoardModel {

    private final AdminDashboardView adminDashboardView;

    public AdminDashBoardModel(AdminDashboardView adminDashboardView){
          this.adminDashboardView = adminDashboardView;
    }

    public void onDataLoaded(){
        adminDashboardView.onDataLoaded();
    }
}
