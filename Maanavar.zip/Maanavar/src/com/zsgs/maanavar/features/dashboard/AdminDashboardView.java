package com.zsgs.maanavar.features.dashboard;


import com.zsgs.maanavar.features.login.LoginView;
import com.zsgs.maanavar.features.manageAdmin.ManageView;
import com.zsgs.maanavar.features.schedule.ScheduleView;

import java.util.Scanner;

public class AdminDashboardView {

    private final AdminDashBoardModel adminDashBoardModel;
    private final ManageView manageView;
    private final ScheduleView scheduleView;
    private final Scanner scanner = new Scanner(System.in);

    public AdminDashboardView(){
        this.adminDashBoardModel =new AdminDashBoardModel(this);
        this.manageView=new ManageView(this);
        this.scheduleView=new ScheduleView();
    }

    public void showDashBoard(){
        boolean isRunning=true;
        while(isRunning){
            printMenu();
            String option=scanner.next();
            switch (option) {
                case "1":
                    manageView.showAddStudentForm();
                    break;
                case "2":
                    manageView.showAddFacultyForm();
                    break;
                case "3":
                    manageView.showStudentDetails();
                    break;
                case "4":
                    manageView.showFacultyList();
                    break;
                case "5":
                    scheduleView.showSchedule();
                    break;
                case "6":
                    System.out.println("System is logging out...");
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid option...Try again");
            }
        }
        System.out.println("Do you want to login again? (Y/N)");
        String s=scanner.next();
        if(s.equals("Y")){
            new LoginView().initLogin();
        }else{
            System.out.println("Thank you for using the Manavar app");
        }
    }
    private void printMenu(){
        System.out.println("====DashBoard====");
        System.out.println("1. Add Students");
        System.out.println("2. Add Faculty");
        System.out.println("3. View Students");
        System.out.println("4. View Faculty");
        System.out.println("5. View Schedule");
        System.out.println("6. Logout");
        System.out.println("Choose an option: ");
    }

    public void onDataLoaded() {
        System.out.println("Data is Loaded");
    }


    public void onError(String message) {
        System.out.println("Error: " + message);
    }

}
