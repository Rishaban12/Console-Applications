package com.zsgs.maanavar.features.dashboard;

import com.zsgs.maanavar.features.login.LoginView;
import com.zsgs.maanavar.features.schedule.ScheduleView;
import com.zsgs.maanavar.features.subject.SubjectView;
import com.zsgs.maanavar.features.task.TaskView;
import com.zsgs.maanavar.features.manageStudents.ManageStudentView;

import java.util.Scanner;

public class StudentDashBoardView {

private final Scanner sc=new Scanner(System.in);
private final ManageStudentView manageStudentView;
private final SubjectView subjectView;
private final TaskView taskView;
private final ScheduleView scheduleView;

public StudentDashBoardView(){
    manageStudentView=new ManageStudentView();
    subjectView=new SubjectView();
    taskView=new TaskView();
    scheduleView=new ScheduleView();
}
    public void showDashBoard() {
        printMenu();
        boolean run = true;

        while (run) {
            System.out.println("Choose the option (1-9): ");
            int option = sc.nextInt();

            switch (option) {
                case 1:
                    manageStudentView.seeAttendance();
                    break;
                case 2:
                    subjectView.seeSubject();
                    break;
                case 3:
                    taskView.seeTask();
                    break;
                case 4:
                    scheduleView.showSchedule();
                    break;
                case 5:
                    manageStudentView.iDidThis();
                    break;
                case 6:
                    manageStudentView.viewIDidThis();
                    break;
                case 7:
                    taskView.taskStatusView();
                    break;
                case 8:
                    manageStudentView.putFeedback();
                    break;
                case 9:
                    System.out.println("System is logging out.....");
                    run = false;
                    break;
                default:
                    System.out.println("Please give a valid option");
            }
        }
        System.out.println("Do you want to login again (Y/N): ");
        String op = sc.next();
        if (op.equals("Y")) {
            new LoginView().initLogin();
        } else {
            System.out.println("Thank you for using the app");
        }
    }
    public void printMenu(){
        System.out.println("===Student Portal===");
        System.out.println("1. See the Attendance");
        System.out.println("2. Subject Info");
        System.out.println("3. Task");
        System.out.println("4. Schedule Info");
        System.out.println("5. I Did This");
        System.out.println("6. View I Did This");
        System.out.println("7. View Task Status");
        System.out.println("8. Give Feedback");
        System.out.println("9. Logout");
    }
}
