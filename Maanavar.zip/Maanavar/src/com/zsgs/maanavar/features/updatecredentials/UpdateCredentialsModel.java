package com.zsgs.maanavar.features.updatecredentials;

import com.zsgs.maanavar.repository.MaanavarDB;

public class UpdateCredentialsModel {

    private final UpdateCredentialsView updateCredentialsView;

    public UpdateCredentialsModel(UpdateCredentialsView updateCredentialsView){
        this.updateCredentialsView=updateCredentialsView;
    }

    public void changePassword(String newPassword) {
        MaanavarDB.getInstance().updatePassword(newPassword);
            updateCredentialsView.onPasswordUpdateSuccess();
        }
    }

