package com.zsgs.maanavar.features.updatecredentials;

import java.util.Scanner;

public class UpdateCredentialsView {

    private final UpdateCredentialsModel updateCredentialsModel;
    private final Scanner scanner = new Scanner(System.in);


    public UpdateCredentialsView(){
        this.updateCredentialsModel=new UpdateCredentialsModel(this);
    }


    public void changePassword() {
        System.out.println("Your Password is wrong");
        System.out.println("Enter your new Password");
        String newPassword= scanner.next();
        updateCredentialsModel.changePassword(newPassword);
    }

    public void onPasswordUpdateSuccess() {
        System.out.println("Successfully login");
    }

    public void onError(String message) {
        System.out.println("Error: " + message);
    }
}
