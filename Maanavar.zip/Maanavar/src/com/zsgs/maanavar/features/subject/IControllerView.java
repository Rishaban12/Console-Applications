package com.zsgs.maanavar.features.subject;
import com.zsgs.maanavar.dto.SubjectInfo;
import java.util.List;

public interface IControllerView {
    abstract List<SubjectInfo> seeSubject();
}
