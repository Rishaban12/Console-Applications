package com.zsgs.maanavar.features.subject;

import com.zsgs.maanavar.repository.MaanavarDB;
import com.zsgs.maanavar.dto.SubjectInfo;

import java.util.List;

public class SubjectModel implements IModelController{
    private final IControllerModel subjectController;

    public SubjectModel(SubjectController subjectController){
        this.subjectController=subjectController;
    }
    public void subjectAdd(){

    }

    @Override
    public List<SubjectInfo> seeSubject() {
        return MaanavarDB.getInstance().seeSubject();
    }
}
