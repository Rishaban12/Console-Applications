package com.zsgs.maanavar.features.subject;

import com.zsgs.maanavar.features.dashboard.StudentDashBoardView;
import com.zsgs.maanavar.dto.SubjectInfo;

import java.util.List;

public class SubjectView implements IViewController{
    private final IControllerView subjectController;
//    private final StudentDashBoardView studentDashBoardView;

    public SubjectView(){
        subjectController=new SubjectController(this);
//        this.studentDashBoardView=studentDashBoardView;
    }

    public void subjectAdded() {

    }

    public void seeSubject() {
       List<SubjectInfo> list= subjectController.seeSubject();

       if(list.isEmpty()){
           System.out.println("Subject is empty");
       }
        System.out.println("======Subject List======");
       for(SubjectInfo x: list){
           System.out.println("Subject Code: "+x.getCode()+"\n"+
                   "Subject Name: "+x.getName()+"\n"+
                   "Subject Type: "+x.getType()+"\n"+
                   "------------------------------------");
       }
        System.out.println("=========================");
    }
}
