package com.zsgs.maanavar.features.subject;
import com.zsgs.maanavar.dto.SubjectInfo;
import java.util.List;

public class SubjectController implements IControllerView,IControllerModel{
    private final IViewController subjectView;
    private final IModelController subjectModel;
    public SubjectController(SubjectView subjectView){
        this.subjectView=subjectView;
        subjectModel=new SubjectModel(this);
    }

    @Override
    public List<SubjectInfo> seeSubject() {
       return subjectModel.seeSubject();
    }
}
