package com.zsgs.maanavar.features.subject;

public interface IControllerModel {
}
