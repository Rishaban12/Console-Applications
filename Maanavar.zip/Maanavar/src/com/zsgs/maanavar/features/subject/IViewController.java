package com.zsgs.maanavar.features.subject;

public interface IViewController {
}
