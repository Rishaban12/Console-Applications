package com.zsgs.maanavar.features.subject;

import com.zsgs.maanavar.dto.SubjectInfo;

import java.util.List;

public interface IModelController {
      abstract List<SubjectInfo> seeSubject();
}
