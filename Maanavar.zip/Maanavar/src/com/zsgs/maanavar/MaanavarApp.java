package com.zsgs.maanavar;

import com.zsgs.maanavar.features.login.LoginView;

public class MaanavarApp {
    public static final String version="0.0.1";

    public static void main(String[] args) {
        MaanavarApp maanavarApp=new MaanavarApp();
        maanavarApp.init();
        }

    private void init() {
        System.out.println("welcome to the Maanavar App! "+version);
        LoginView loginView =new LoginView();
        loginView.initLogin();
    }
}
