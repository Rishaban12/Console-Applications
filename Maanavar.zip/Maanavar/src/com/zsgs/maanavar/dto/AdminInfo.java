package com.zsgs.maanavar.dto;

public class AdminInfo {
    private String adminId;
    private String name;
    private String email;
    private String contactNo;

    public AdminInfo() {}

    public AdminInfo(String adminId, String name, String email, String contactNo) {
        this.adminId = adminId;
        this.name = name;
        this.email = email;
        this.contactNo = contactNo;
    }

    public String getAdminId() { return adminId; }
    public void setAdminId(String adminId) { this.adminId = adminId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getContactNo() { return contactNo; }
    public void setContactNo(String contactNo) { this.contactNo = contactNo; }
}
