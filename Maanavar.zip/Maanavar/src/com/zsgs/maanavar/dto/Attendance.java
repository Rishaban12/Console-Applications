package com.zsgs.maanavar.dto;

public class Attendance {
    private int attendanceId;
    private String studentId;
    private String subjectId;
    private String date;
    private String status;      // Present, Absent, Late, Excused
    private String recordedAt;

    public Attendance() {}

    public Attendance(int attendanceId, String studentId, String subjectId,
                      String date, String status, String recordedAt) {
        this.attendanceId = attendanceId;
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.date = date;
        this.status = status;
        this.recordedAt = recordedAt;
    }

    public int getAttendanceId() { return attendanceId; }
    public void setAttendanceId(int attendanceId) { this.attendanceId = attendanceId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getSubjectId() { return subjectId; }
    public void setSubjectId(String subjectId) { this.subjectId = subjectId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRecordedAt() { return recordedAt; }
    public void setRecordedAt(String recordedAt) { this.recordedAt = recordedAt; }
}
