package com.zsgs.maanavar.dto;

public class  LoginCredentials {
    private String id;
    private String userName;   // RollNo for student
    private String password;

    public LoginCredentials() {}

    public LoginCredentials(String id, String userName, String password) {
        this.id = id;
        this.userName = userName;
        this.password = password;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}

