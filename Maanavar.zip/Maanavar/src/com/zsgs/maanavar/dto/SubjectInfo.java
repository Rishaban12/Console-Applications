package com.zsgs.maanavar.dto;

public class SubjectInfo {
    private String code;
    private String name;
    private String type;

    public SubjectInfo() {}

    public SubjectInfo(String code, String name, String type) {
        this.code = code;
        this.name = name;
        this.type = type;
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    @Override
    public String toString() {
        return "SubejctCode: "+code + " --> " + name + " (" + type + ")";
    }
}

