package com.zsgs.maanavar.dto;

public class StudentFeedback {
    private String studentId;
    private String facultyId;
    private String subjectCode;
    private String feedback;
    private String time;

    public StudentFeedback() {}

    public StudentFeedback(String studentId, String facultyId, String subjectCode,
                           String feedback, String time) {
        this.studentId = studentId;
        this.facultyId = facultyId;
        this.subjectCode = subjectCode;
        this.feedback = feedback;
        this.time = time;
    }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getFacultyId() { return facultyId; }
    public void setFacultyId(String facultyId) { this.facultyId = facultyId; }

    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }

    public String getFeedback() { return feedback; }
    public void setFeedback(String feedback) { this.feedback = feedback; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
}
