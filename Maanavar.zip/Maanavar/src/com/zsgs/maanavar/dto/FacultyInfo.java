package com.zsgs.maanavar.dto;

import java.util.List;

public class FacultyInfo {
    private String empId;
    private String name;
    private List<SubjectInfo> subjects;
    private String email;
    private String contactNo;

    public FacultyInfo() {}

    public FacultyInfo(String empId, String name, List<SubjectInfo> subjects,
                       String email, String contactNo) {
        this.empId = empId;
        this.name = name;
        this.subjects = subjects;
        this.email = email;
        this.contactNo = contactNo;
    }

    public String getEmpId() { return empId; }
    public void setEmpId(String empId) { this.empId = empId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<SubjectInfo> getSubjects() { return subjects; }
    public void setSubjects(List<SubjectInfo> subjects) { this.subjects = subjects; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getContactNo() { return contactNo; }
    public void setContactNo(String contactNo) { this.contactNo = contactNo; }
}
