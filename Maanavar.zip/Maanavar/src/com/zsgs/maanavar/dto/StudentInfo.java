package com.zsgs.maanavar.dto;

public class StudentInfo {
    private String name;
    private String mailId;
    private String contactNo;
    private String rollNo;
    private String dept;

    public StudentInfo() {}

    public StudentInfo(String name, String mailId, String contactNo, String rollNo, String dept) {
        this.name = name;
        this.mailId = mailId;
        this.contactNo = contactNo;
        this.rollNo = rollNo;
        this.dept = dept;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getMailId() { return mailId; }
    public void setMailId(String mailId) { this.mailId = mailId; }

    public String getContactNo() { return contactNo; }
    public void setContactNo(String contactNo) { this.contactNo = contactNo; }

    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }

    public String getDept() { return dept; }
    public void setDept(String dept) { this.dept = dept; }
}
