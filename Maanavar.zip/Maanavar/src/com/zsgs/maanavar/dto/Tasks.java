package com.zsgs.maanavar.dto;

public class Tasks {
    private int taskId;
    private String subjectCode;
    private String facultyId;
    private String taskDesc;
    private String givenDate;
    private String deadline;

    public Tasks() {}

    public Tasks(int taskId, String subjectCode, String facultyId, String taskDesc,
                 String givenDate, String deadline) {
        this.taskId = taskId;
        this.subjectCode = subjectCode;
        this.facultyId = facultyId;
        this.taskDesc = taskDesc;
        this.givenDate = givenDate;
        this.deadline = deadline;
    }

    public int getTaskId() { return taskId; }
    public void setTaskId(int taskId) { this.taskId = taskId; }

    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }

    public String getFacultyId() { return facultyId; }
    public void setFacultyId(String facultyId) { this.facultyId = facultyId; }

    public String getTaskDesc() { return taskDesc; }
    public void setTaskDesc(String taskDesc) { this.taskDesc = taskDesc; }

    public String getGivenDate() { return givenDate; }
    public void setGivenDate(String givenDate) { this.givenDate = givenDate; }

    public String getDeadline() { return deadline; }
    public void setDeadline(String deadline) { this.deadline = deadline; }
}
