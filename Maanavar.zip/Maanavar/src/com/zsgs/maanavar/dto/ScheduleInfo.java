package com.zsgs.maanavar.dto;

public class ScheduleInfo {
    private Slot slot1;
    private Slot slot2;
    private String date;
    private String scheduleId;

    public ScheduleInfo() {}

    public ScheduleInfo(Slot slot1, Slot slot2, String date, String scheduleId) {
        this.slot1 = slot1;
        this.slot2 = slot2;
        this.date = date;
        this.scheduleId = scheduleId;
    }

    public Slot getSlot1() { return slot1; }
    public void setSlot1(Slot slot1) { this.slot1 = slot1; }

    public Slot getSlot2() { return slot2; }
    public void setSlot2(Slot slot2) { this.slot2 = slot2; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getScheduleId() { return scheduleId; }
    public void setScheduleId(String scheduleId) { this.scheduleId = scheduleId; }
}
