package com.zsgs.maanavar.dto;

public class TaskStatus {
    private int taskStatusId;
    private int taskId;
    private String studentId;
    private String task;
    private String completionStatus;  // Completed, Pending, Partially
    private String review;
    private String reviewedFacultyId;

    public TaskStatus() {}

    public TaskStatus(int taskStatusId, int taskId, String studentId, String task,
                      String completionStatus, String review, String reviewedFacultyId) {
        this.taskStatusId = taskStatusId;
        this.taskId = taskId;
        this.studentId = studentId;
        this.task = task;
        this.completionStatus = completionStatus;
        this.review = review;
        this.reviewedFacultyId = reviewedFacultyId;
    }

    public int getTaskStatusId() { return taskStatusId; }
    public void setTaskStatusId(int taskStatusId) { this.taskStatusId = taskStatusId; }

    public int getTaskId() { return taskId; }
    public void setTaskId(int taskId) { this.taskId = taskId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getTask() { return task; }
    public void setTask(String task) { this.task = task; }

    public String getCompletionStatus() { return completionStatus; }
    public void setCompletionStatus(String completionStatus) { this.completionStatus = completionStatus; }

    public String getReview() { return review; }
    public void setReview(String review) { this.review = review; }

    public String getReviewedFacultyId() { return reviewedFacultyId; }
    public void setReviewedFacultyId(String reviewedFacultyId) { this.reviewedFacultyId = reviewedFacultyId; }
}
