package com.zsgs.maanavar.dto;

public class IDidThis {
    private String studentId;
    private String date;
    private String description;

    public IDidThis() {}

    public IDidThis(String studentId, String date, String description) {
        this.studentId = studentId;
        this.date = date;
        this.description = description;
    }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}
