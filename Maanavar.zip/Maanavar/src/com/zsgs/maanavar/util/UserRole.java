package com.zsgs.maanavar.util;

public enum UserRole{
    ADMIN,
    FACULTY,
    STUDENT,
    INVALID
}
