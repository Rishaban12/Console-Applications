package com.clg.student.features;

import com.clg.student.dashboard.DashBoard;
import com.clg.student.student.dto.StudentPojo;

import java.util.List;
import java.util.Scanner;

public class StudentView implements IControllerView{

    private Scanner scanner=new Scanner(System.in);
    private final IViewController studentController;
    private final DashBoard dashBoard;

    public StudentView(){
        studentController= new StudentController(this);
        dashBoard=new DashBoard(this);
    }
    public void initLogin(){
        dashBoard.DashBoardView();
    }

    public void enterDetails() {
        System.out.println("enter your name");
        String name=scanner.next();
        System.out.println("enter your dept");
        String dept=scanner.next();
        System.out.println("enter your email");
        String email=scanner.next();
        System.out.println("enter your phone");
        String phone=scanner.next();
        studentController.store(name,dept,email,phone);
    }

    public void viewDetails(){
        List<StudentPojo> student= studentController.getDetails();

        for(StudentPojo sp: student){
            System.out.println("---------------Student Report---------------------");
            System.out.println("Name: "+sp.getName()+"\n"+"Dept: "+sp.getDept()+"\n"+"Email: "+sp.getEmail()+"\n"+"PhoneNo: "+sp.getPhoneNo());
            System.out.println("--------------------------------------------------");
        }

        dashBoard.DashBoardView();
    }

    public void printSuccess() {
        System.out.println("Successfully Added");
        dashBoard.DashBoardView();
    }
}
