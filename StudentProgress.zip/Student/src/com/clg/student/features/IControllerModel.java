package com.clg.student.features;

import com.clg.student.student.dto.StudentPojo;

import java.util.*;

public interface IControllerModel {
    abstract void store(String name,String dept,String email,String phone);

     abstract List<StudentPojo> getDetails();
}
