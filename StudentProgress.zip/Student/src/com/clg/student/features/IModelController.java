package com.clg.student.features;

public interface IModelController {

   abstract void printSuccess();
}
