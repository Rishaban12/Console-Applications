package com.clg.student.features;

import com.clg.student.repo.StudentDb;
import com.clg.student.student.dto.StudentPojo;

import java.util.List;
public class StudentModel implements IControllerModel{
    private final IModelController studentController;
    public StudentModel(IModelController studentController){
        this.studentController=studentController;
    }

    public void store(String name,String dept,String email,String phone){
        StudentPojo sp=new StudentPojo();
        sp.setName(name);
        sp.setDept(dept);
        sp.setEmail(email);
        sp.setPhoneNo(phone);

       if( StudentDb.getInstance().storeStudents(sp)) {
           studentController.printSuccess();
       }
    }

    public List<StudentPojo> getDetails(){
        return StudentDb.getInstance().getStudents();
    }
}
