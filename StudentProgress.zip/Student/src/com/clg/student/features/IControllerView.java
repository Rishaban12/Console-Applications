package com.clg.student.features;

public interface IControllerView {
    abstract void printSuccess();
}
