package com.clg.student.features;

import com.clg.student.student.dto.StudentPojo;

import java.util.List;

public class StudentController implements IViewController,IModelController {
    private final IControllerView studentView;
    private final IControllerModel studentModel;

    public StudentController(IControllerView studentView) {
        this.studentView=studentView;
        studentModel =new StudentModel(this);
    }


   public List<StudentPojo> getDetails(){
       return studentModel.getDetails();
   }
   public void store(String name,String dept,String email,String phone){
        studentModel.store(name,dept,email,phone);
   }
   public void printSuccess(){
        studentView.printSuccess();
   }

}
