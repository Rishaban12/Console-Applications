package com.clg.student.student.dto;

public class StudentPojo {
    private String name;
    private String dept;
    private String email;
    private String phoneNo;


    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }

    public void setDept(String dept){
        this.dept=dept;
    }
    public String getDept(){
        return dept;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }
}
