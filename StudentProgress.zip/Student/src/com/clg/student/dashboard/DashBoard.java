package com.clg.student.dashboard;
import com.clg.student.features.StudentView;
import java.util.Scanner;

public class DashBoard {
    private Scanner scanner=new Scanner(System.in);
    private final StudentView studentView;

    public DashBoard(StudentView studentView){
        this.studentView=studentView;
    }

    public void DashBoardView() {
           DashBoard.printMenu();
           boolean find=true;

           while(find){
               String option=scanner.next();
               switch (option){
                   case "1":
                       studentView.enterDetails();
                       break;
                   case "2":
                       studentView.viewDetails();
                       break;
                   case "3":
                       System.out.println("Thank you for visiting my app");
                       find=false;
                       break;
                   default:
                       System.out.println("Please enter the valid answer");
                       break;
               }
           }
    }
    static void printMenu(){
        System.out.println("1. Enter the Students Details");
        System.out.println("2. See the Students Details");
        System.out.println("3. Exit");
        System.out.println("Choose the option (1,2,3)-->");
    }
}
