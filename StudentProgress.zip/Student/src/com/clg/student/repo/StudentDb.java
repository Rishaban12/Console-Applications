package com.clg.student.repo;

import com.clg.student.student.dto.StudentPojo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentDb {

    private static StudentDb sDb=null;
    List<StudentPojo> students=new ArrayList<>();

    public static StudentDb getInstance() {
        if (sDb == null) {
            sDb = new StudentDb();
            return sDb;
        }
        return sDb;
    }

    public boolean storeStudents(StudentPojo student) {

        String sql = "INSERT INTO student(name, dept, email, phone) VALUES (?, ?, ?, ?)";
        int row=0;
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, student.getName());
            ps.setString(2, student.getDept());
            ps.setString(3, student.getEmail());
            ps.setString(4, student.getPhoneNo());

          row=  ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return row>0;
    }
//    public void storeStudents(StudentPojo studentPojo){
//        students.add(studentPojo);
//    }
//    public List<StudentPojo> getStudents(){
//        return students;
//    }
public List<StudentPojo> getStudents() {

    List<StudentPojo> list = new ArrayList<>();
    String sql = "SELECT * FROM student";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            StudentPojo sp = new StudentPojo();
            sp.setName(rs.getString("name"));
            sp.setDept(rs.getString("dept"));
            sp.setEmail(rs.getString("email"));
            sp.setPhoneNo(rs.getString("phone"));
            list.add(sp);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }
    return list;
}
}
