import com.clg.student.features.StudentView;

public class StudentReportApp {
    public static void main(String[] args) {
        StudentReportApp st=new StudentReportApp();
        st.init();
    }
    public void init(){
        System.out.println("Welcome to our app");
        StudentView v=new StudentView();
        v.initLogin();
    }
}
