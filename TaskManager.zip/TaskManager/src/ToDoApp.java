import com.task.todo.features.login.LoginView;

public class ToDoApp {
    public static final String version="0.0.1";

    public static void main(String[] args) {
        ToDoApp toDoApp=new ToDoApp();
        toDoApp.init();
    }

    private void init() {
        System.out.println("Welcome to our ToDoApp: "+version);
        LoginView loginView=new LoginView();
        loginView.initLogin();
        System.out.println("Thank you for visiting our app");
    }
}
