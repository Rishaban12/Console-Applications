package com.task.todo.repo;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ToDoDb {
    private static ToDoDb s=null;
    private final List<Task> addUser=new ArrayList<>();
    public static ToDoDb getInstance() {
        if(s==null){
            s=new ToDoDb();
        }
        return s;
    }

    public boolean validateCredentials(String userName, int password) {
        if(userName.equals("rishab") && password==123456){
            return true;
        }
        return false;
    }

    public void addBack(int id, String taskDesc, LocalDate curdate, LocalDate dueDate, Level level, String status) {
        Task task=new Task(id,taskDesc,curdate,dueDate,level,status);
        addUser.add(task);
    }

    public List<Task> view() {
        return addUser;
    }

    public List<Task> view(String status) {
        List<Task> list=new ArrayList<>();

        for(Task t: addUser){
            if(t.getStatus().equals(status)){
                list.add(t);
            }
        }
        return list;
    }

    public List<Task> view(Level level){
        List<Task> list=new ArrayList<>();

        for(Task t: addUser){
            if(t.getLevel()==level){
                list.add(t);
            }
        }
        return list;
    }

    public void deleteId(int id) {
        for(Task t: addUser){
            if(t.getTaskId()==id){
                addUser.remove(t);
                break;
            }
        }
    }

    public List<Task> viewById(int id) {
        List<Task> list=new ArrayList<>();
        for(Task t: addUser){
            if(t.getTaskId()==id){
                list.add(t);
            }
        }
        return list;
    }

    public void newStatus(String status,int id) {
        for(Task t: addUser){
            if(t.getTaskId()==id){
                t.setStatus(status);
            }
        }
    }

    public void newDueDate(LocalDate end,int id) {
        for(Task t: addUser){
            if(t.getTaskId()==id){
                t.setDueDate(end);
            }
        }
    }

    public void newCurDate(LocalDate start,int id) {
        for(Task t: addUser){
            if(t.getTaskId()==id){
                t.setCurDate(start);
            }
        }
    }

    public void newTaskDesc(String taskDesc,int id) {
        for(Task t: addUser){
            if(t.getTaskId()==id){
               t.setTaskDesc(taskDesc);
            }
        }
    }

    public void newPriority(Level l,int id) {
        for(Task t: addUser){
            if(t.getTaskId()==id){
              t.setLevel(l);
            }
        }
    }
}
