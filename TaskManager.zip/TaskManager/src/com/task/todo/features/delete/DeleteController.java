package com.task.todo.features.delete;

public class DeleteController implements IDeleteViewController,IDeleteModelController{
    private final IControllerDeleteView deleteView;
    private final IControllerDeleteModel deleteModel;

    public DeleteController(DeleteView deleteView){
        this.deleteView=deleteView;
        deleteModel=new DeleteModel(this);
    }

    @Override
    public void deleteId(int id) {
       deleteModel.deleteId(id);
    }
}
