package com.task.todo.features.delete;


import com.task.todo.features.show.IShowModelController;
import com.task.todo.repo.ToDoDb;

public class DeleteModel implements IControllerDeleteModel {
    private final IDeleteModelController deleteController;

    public DeleteModel(DeleteController deleteController){
        this.deleteController=deleteController;
    }

    @Override
    public void deleteId(int id) {
        ToDoDb.getInstance().deleteId(id);
    }
}
