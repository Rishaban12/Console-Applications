package com.task.todo.features.delete;

public interface IDeleteViewController {
    abstract void deleteId(int id);
}
