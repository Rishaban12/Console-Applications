package com.task.todo.features.delete;

import com.task.todo.features.show.ShowView;

import java.util.Scanner;

public class DeleteView implements IControllerDeleteView{
    private final IDeleteViewController deleteController;
    private final ShowView showView;
    private final Scanner sc=new Scanner(System.in);

    public DeleteView(ShowView showView){
        deleteController=new DeleteController(this);
        this.showView=showView;
    }

    public void delete() {
            showView.view();
            int id=0;
            System.out.println("Which Task do you want to delete(Enter their id): ");
            while(true) {
                try {
                    System.out.println("Enter the Task Id: ");
                    id = Integer.parseInt(sc.nextLine());
                    if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                        break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Please provide the valid id");
                }
            }
            deleteController.deleteId(id);
            System.out.println("Successfully deleted");
            showView.view();
    }
}
