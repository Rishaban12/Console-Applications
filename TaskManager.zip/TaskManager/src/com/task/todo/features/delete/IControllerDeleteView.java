package com.task.todo.features.delete;

public interface IControllerDeleteView {
}
