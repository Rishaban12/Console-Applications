package com.task.todo.features.delete;

public interface IControllerDeleteModel {
    abstract void deleteId(int id);
}
