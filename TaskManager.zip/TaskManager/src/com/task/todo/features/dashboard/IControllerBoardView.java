package com.task.todo.features.dashboard;

public interface IControllerBoardView {
}
