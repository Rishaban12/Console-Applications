package com.task.todo.features.dashboard;

class BoardController implements IBoardViewController,IBoardModelController{
    private final IControllerBoardView dashBoardView;
    private final IControllerBoardModel BoardModel;

    public BoardController(DashboardView dashboardView){
        this.dashBoardView=dashboardView;
        BoardModel=new DashboardModel(this);
    }
}
