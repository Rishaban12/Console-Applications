package com.task.todo.features.dashboard;

import com.task.todo.features.add.AddTaskView;
import com.task.todo.features.delete.DeleteView;
import com.task.todo.features.login.LoginView;
import com.task.todo.features.show.ShowView;
import com.task.todo.features.update.UpdateView;

import java.util.Scanner;

public class DashboardView implements IControllerBoardView {
    private final IBoardViewController boardController;
    private final Scanner sc=new Scanner(System.in);

    public DashboardView(){
        boardController=new BoardController(this);
    }
    public void showDashBoard() {
        int opt=0;
        boolean logout=false;
        boolean flag=true;
        f: while (flag){
            print();
            opt=Integer.parseInt(sc.nextLine());
            switch (opt){
                case 1:
                   new AddTaskView().add();
                    break;
                case 2:
                    new ShowView().show();
                    break;
                case 3:
                    new UpdateView().update();
                    break;
                case 4:
                    new DeleteView(new ShowView()).delete();
                    break;
                case 5:
                    System.out.println("System is logging out...");
                    logout=true;
                    flag=false;
                    break f;
                case 6:
                    flag=false;
                    break f;
                default:
                    System.out.println("Please provide the valid option");
            }
        }
        if(logout){
            System.out.println("Do you want to login again(Y/N): ");
            f: while(true) {
                try {
                    String op=sc.nextLine();
                    if(op.equals("Y") || op.equals("y")){
                        new LoginView().initLogin();
                    }else if(op.equals("N") || op.equals("n")){
                        break f;
                    }
                } catch (Exception e) {
                    System.out.println("Please enter the valid option");
                }
            }
        }
    }
    public void print(){
        System.out.println("======DashBoard=======");
        System.out.println("1. Add the task");
        System.out.println("2. View the task");
        System.out.println("3. Update the task");
        System.out.println("4. Delete the task");
        System.out.println("5. LogOut");
        System.out.println("6. Exit");
        System.out.println("Choose the valid option(1-6): ");
    }
}
