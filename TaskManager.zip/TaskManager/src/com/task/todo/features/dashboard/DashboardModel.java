package com.task.todo.features.dashboard;

public class DashboardModel implements IControllerBoardModel{
    private final IBoardModelController boardController;

    public DashboardModel(BoardController boardController){
        this.boardController=boardController;
    }

}
