package com.task.todo.features.add;

import com.task.todo.dto.Level;

import java.time.LocalDate;

public class AddTaskController implements ITaskViewController,ITaskModelController{
    private final IControllerTaskView taskView;
    private final IControllerTaskModel taskModel;

    public AddTaskController(AddTaskView taskView){
        this.taskView=taskView;
        taskModel=new AddTaskModel(this);
    }

    @Override
    public void addBack(int id, String taskDesc, LocalDate curdate, LocalDate dueDate, Level level, String status) {
        taskModel.addBack(id,taskDesc,curdate,dueDate,level,status);
    }
}
