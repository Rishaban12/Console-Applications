package com.task.todo.features.add;

import com.task.todo.dto.Level;
import com.task.todo.repo.ToDoDb;

import java.time.LocalDate;

public class AddTaskModel implements IControllerTaskModel{
    private final ITaskModelController taskController;

    public AddTaskModel(AddTaskController taskController){
        this.taskController=taskController;
    }

    @Override

    public void addBack(int id, String taskDesc, LocalDate curdate, LocalDate dueDate, Level level, String status) {
        ToDoDb.getInstance().addBack(id,taskDesc,curdate,dueDate,level,status);
    }
}
