package com.task.todo.features.add;

import com.task.todo.dto.Level;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class AddTaskView implements IControllerTaskView{
    private final ITaskViewController addTaskController;
    private final Scanner sc=new Scanner(System.in);

    public AddTaskView(){
        addTaskController=new AddTaskController(this);
    }
    public void add() {
           int id=0;
           String taskDesc="";
           LocalDate date=null;
           LocalDate dat=null;
           int level=0;
           String status="";


        while(true) {
            try {
                System.out.println("Enter the Task Id: ");
                id = Integer.parseInt(sc.nextLine());
                if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }
             while(true) {
                 try {
                     System.out.println("Enter the Task Description: ");
                     taskDesc = sc.nextLine();
                     if(!(taskDesc.equals(""))){
                         break;
                     }
                 } catch (Exception e) {
                     System.out.println("Please provide the valid text");
                 }
             }
           while(true){
            try {
                System.out.println("Enter the Start Date (dd-MM-yyyy)");
                String input = sc.nextLine();
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                dat = LocalDate.parse(input, dateTimeFormatter);
                break;
            } catch (DateTimeParseException e) {
                System.out.println("Invalid...");
            }
          }

             while(true){
                 try {
                     System.out.println("Enter the Due Date (dd-MM-yyyy)");
                     String input = sc.nextLine();
                     DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                     date = LocalDate.parse(input, dateTimeFormatter);
                     break;
                 } catch (DateTimeParseException e) {
                     System.out.println("Invalid...");
                 }
             }

             while(true){
                 try {
                     System.out.println("Set the priority");
                     System.out.println("1. LOW");
                     System.out.println("2. MEDIUM");
                     System.out.println("3. HIGH");
                     System.out.println("Enter the valid option(1-3): ");
                     level = Integer.parseInt(sc.nextLine());
                     if (level >= 1 && level <= 3) {
                         break;
                     }
                 }catch (NumberFormatException e){
                     System.out.println("Please provide the valid option");
                 }
             }
                while(true) {
                   try {
                      System.out.println("Enter the Status(Completed/ongoing/not started/partially completed): ");
                      status = sc.nextLine();
                      if(!(status.equals(""))){
                        break;
                      }
                   } catch (Exception e) {
                      System.out.println("Please provide the valid text");
                }
        }
        Level l=null;
                switch (level){
                    case 1:
                        l=Level.LOW;
                        break;
                    case 2:
                        l=Level.MEDIUM;
                        break;
                    case 3:
                        l=Level.HIGH;
                        break;
                }
           addTaskController.addBack(id,taskDesc,dat,date,l,status);
        System.out.println("Successfully Added!!!");
    }
}
