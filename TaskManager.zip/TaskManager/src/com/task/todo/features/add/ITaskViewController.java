package com.task.todo.features.add;

import com.task.todo.dto.Level;

import java.time.LocalDate;

public interface ITaskViewController {
    abstract void addBack(int id, String taskDesc, LocalDate curdate, LocalDate dueDate, Level level, String status);
}
