package com.task.todo.features.show;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;
import com.task.todo.repo.ToDoDb;

import java.util.Collections;
import java.util.List;

public class ShowModel implements IControllerShowModel{
    private final IShowModelController showController;

    public ShowModel(ShowController showController){
        this.showController=showController;
    }

    @Override
    public List<Task> view() {
        return ToDoDb.getInstance().view();
    }

    @Override
    public List<Task> view(String status) {
        return ToDoDb.getInstance().view(status);
    }

    @Override
    public List<Task> view(Level level) {
        return ToDoDb.getInstance().view(level);
     }
}
