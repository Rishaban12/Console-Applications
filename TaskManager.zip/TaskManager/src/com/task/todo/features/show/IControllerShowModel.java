package com.task.todo.features.show;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;

import java.util.List;

public interface IControllerShowModel {
    abstract List<Task> view();

    abstract List<Task> view(String status);

    abstract List<Task> view(Level level);
}
