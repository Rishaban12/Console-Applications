package com.task.todo.features.show;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;

import java.util.Collections;
import java.util.List;

public class ShowController implements IShowViewController,IShowModelController{
    private final IControllerShowView showView;
    private final IControllerShowModel showModel;

    public ShowController(ShowView showView){
        this.showView=showView;
        showModel=new ShowModel(this);
    }

    @Override
    public List<Task> view() {
        return showModel.view();
    }

    @Override
    public List<Task> view(Level level) {
        return showModel.view(level);
    }

    @Override
    public List<Task> view(String status) {
        return showModel.view(status);
    }
}
