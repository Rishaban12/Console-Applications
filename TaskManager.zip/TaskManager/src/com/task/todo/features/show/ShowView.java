package com.task.todo.features.show;


import com.task.todo.dto.Level;
import com.task.todo.dto.Task;
import com.task.todo.features.delete.DeleteView;

import java.util.List;
import java.util.Scanner;

public class ShowView implements IControllerShowView {
    private final IShowViewController showController;
    private final DeleteView deleteView;
    private final Scanner sc=new Scanner(System.in);

    public ShowView(){
        showController=new ShowController(this);
        deleteView=new DeleteView(this);
    }

    public void show() {
        int opt=0;
        String status="";
        int level=0;
      f:  while (true){
            print();
            opt=Integer.parseInt(sc.nextLine());

            switch (opt){
                case 1:
                    view();
                    break;
                case 2:
                    while(true){
                        try {
                            System.out.println("Set the priority");
                            System.out.println("1. LOW");
                            System.out.println("2. MEDIUM");
                            System.out.println("3. HIGH");
                            System.out.println("Enter the valid option(1-3): ");
                            level = Integer.parseInt(sc.nextLine());
                            if (level >= 1 && level <= 3) {
                                break;
                            }
                        }catch (NumberFormatException e){
                            System.out.println("Please provide the valid option");
                        }
                    }
                    Level l=null;
                    switch (level){
                        case 1:
                            l=Level.LOW;
                            break;
                        case 2:
                            l=Level.MEDIUM;
                            break;
                        case 3:
                            l=Level.HIGH;
                            break;
                    }
                    view(l);
                    break;
                case 3:
                    while(true) {
                        try {
                            System.out.println("Enter the Status(Completed/ongoing/not started/partially completed): ");
                            status = sc.nextLine();
                            if (!(status.equals("")) && (status.equals("Completed") || status.equals("ongoing") || status.equals("not started") || status.equals("partially completed"))) {
                                break;
                            }
                        } catch (Exception e) {
                            System.out.println("Please provide the valid text");
                        }
                    }
                    view(status);
                    break;
                case 4:
                    break f;
                default:
                    System.out.println("Please provide the valid option");
            }
        }
    }

    public void print(){
        System.out.println("1. View all task");
        System.out.println("2. View by priority");
        System.out.println("3. View by status");
        System.out.println("4. Exit");
        System.out.println("Choose the valid option(1-4): ");
    }

    public void view(){
         List<Task> list=showController.view();
        System.out.println("-----------------TASK------------------");
         for(Task t: list){
             System.out.println("Task Id: "+t.getTaskId()+"\n"+"Task Description: "+t.getTaskDesc()+"\n"+
                     "Starting Date: "+t.getCurDate()+"\n"+"Due Date: "+t.getDueDate()+"\n"+
                     "Priority: "+t.getLevel()+"\n"+"Status: "+t.getStatus());
         }
        System.out.println("---------------------------------------");
    }

    public void view(Level level){
        List<Task> list=showController.view(level);
        System.out.println("-----------------TASK------------------");
        for(Task t: list){
            System.out.println("Task Id: "+t.getTaskId()+"\n"+"Task Description: "+t.getTaskDesc()+"\n"+
                    "Starting Date: "+t.getCurDate()+"\n"+"Due Date: "+t.getDueDate()+"\n"+
                    "Priority: "+t.getLevel()+"\n"+"Status: "+t.getStatus());
        }
        System.out.println("---------------------------------------");
    }

    public void view(String status){
        List<Task> list=showController.view(status);
        System.out.println("-----------------TASK------------------");
        for(Task t: list){
            System.out.println("Task Id: "+t.getTaskId()+"\n"+"Task Description: "+t.getTaskDesc()+"\n"+
                    "Starting Date: "+t.getCurDate()+"\n"+"Due Date: "+t.getDueDate()+"\n"+
                    "Priority: "+t.getLevel()+"\n"+"Status: "+t.getStatus());
        }
        System.out.println("---------------------------------------");
    }
}
