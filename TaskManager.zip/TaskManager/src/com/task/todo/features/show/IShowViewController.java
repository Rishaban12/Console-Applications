package com.task.todo.features.show;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;

import java.util.List;

public interface IShowViewController {
    abstract List<Task> view();

    abstract List<Task> view(Level level);

    abstract List<Task> view(String status);
}
