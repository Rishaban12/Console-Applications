package com.task.todo.features.login;

public interface IControllerLoginModel {
    abstract void validateCredentials(String userName,int password);
}
