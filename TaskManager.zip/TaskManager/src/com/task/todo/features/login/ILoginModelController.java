package com.task.todo.features.login;

public interface ILoginModelController {
    abstract void onLoginSuccess();
    abstract void onLoginFailed();
}
