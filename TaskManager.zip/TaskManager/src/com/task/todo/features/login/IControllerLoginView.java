package com.task.todo.features.login;

public interface IControllerLoginView {
    abstract void onLoginSuccess();
    abstract void onLoginFailed();
}
