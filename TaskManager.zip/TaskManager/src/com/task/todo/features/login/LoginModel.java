package com.task.todo.features.login;

import com.task.todo.repo.ToDoDb;

public class LoginModel implements IControllerLoginModel{
    private final ILoginModelController loginController;

    public LoginModel(LoginController loginController){
        this.loginController= loginController;
    }

    @Override
    public void validateCredentials(String userName, int password) {
        boolean val= ToDoDb.getInstance().validateCredentials(userName,password);
        if(val){
            loginController.onLoginSuccess();
        }else{
            loginController.onLoginFailed();
        }
    }
}
