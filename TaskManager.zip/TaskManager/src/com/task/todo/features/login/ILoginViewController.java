package com.task.todo.features.login;

public interface ILoginViewController {
    abstract void validateCredentials(String userName,int password);
}
