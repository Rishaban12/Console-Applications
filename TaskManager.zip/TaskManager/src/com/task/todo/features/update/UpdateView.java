package com.task.todo.features.update;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class UpdateView implements IControllerUpdateView{
    private final IUpdateViewController updateController;
    private final Scanner sc=new Scanner(System.in);

    public UpdateView(){
        updateController=new UpdateController(this);
    }

    public void update() {
        int id=0;
        System.out.println("Which task id do you want to update(enter the id): ");
        while(true) {
            try {
                System.out.println("Enter the Task Id: ");
                id = Integer.parseInt(sc.nextLine());
                if(!((id>='a' && id<='z') || (id>='A' && id<='Z'))){
                    break;
                }
            } catch (NumberFormatException e) {
                System.out.println("Please provide the valid id");
            }
        }
        getViewId(id);
        int opt=0;
        f: while(true) {
           print();
           opt=Integer.parseInt(sc.nextLine());
           switch (opt){
               case 1:
                   String taskDesc="";
                   while(true) {
                       try {
                           System.out.println("Enter the new Task Description: ");
                           taskDesc = sc.nextLine();
                           if(!(taskDesc.equals(""))){
                               break;
                           }
                       } catch (Exception e) {
                           System.out.println("Please provide the valid text");
                       }
                   }
                   updateController.newTaskDesc(taskDesc,id);
                   getViewId(id);
                   break;
               case 2:
                   LocalDate start=null;
                   while(true){
                       try {
                           System.out.println("Enter the new Start Date (dd-MM-yyyy)");
                           String input = sc.nextLine();
                           DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                           start = LocalDate.parse(input, dateTimeFormatter);
                           break;
                       } catch (DateTimeParseException e) {
                           System.out.println("Invalid...");
                       }
                   }
                   updateController.newCurDate(start,id);
                   getViewId(id);
                   break;
               case 3:
                   LocalDate end=null;
                   while(true){
                       try {
                           System.out.println("Enter the new Due Date (dd-MM-yyyy)");
                           String input = sc.nextLine();
                           DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                           end = LocalDate.parse(input, dateTimeFormatter);
                           break;
                       } catch (DateTimeParseException e) {
                           System.out.println("Invalid...");
                       }
                   }
                   updateController.newDueDate(end,id);
                   getViewId(id);
                   break;
               case 4:
                   int level=0;
                   while(true){
                       try {
                           System.out.println("Set the priority");
                           System.out.println("1. LOW");
                           System.out.println("2. MEDIUM");
                           System.out.println("3. HIGH");
                           System.out.println("Enter the valid option(1-3): ");
                           level = Integer.parseInt(sc.nextLine());
                           if (level >= 1 && level <= 3) {
                               break;
                           }
                       }catch (NumberFormatException e){
                           System.out.println("Please provide the valid option");
                       }
                   }
                   Level l=null;
                   switch (level){
                       case 1:
                           l=Level.LOW;
                           break;
                       case 2:
                           l=Level.MEDIUM;
                           break;
                       case 3:
                           l=Level.HIGH;
                           break;
                   }
                   updateController.newPriority(l,id);
                   getViewId(id);
                   break;
               case 5:
                   String status="";
                   while(true) {
                       try {
                           System.out.println("Enter the Status(Completed/ongoing/not started/partially completed): ");
                           status = sc.nextLine();
                           if (!(status.equals(""))) {
                               break;
                           }
                       } catch (Exception e) {
                           System.out.println("Please provide the valid text");
                       }
                   }
                   updateController.newStatus(status,id);
                   getViewId(id);
                   break;
               case 6:
                   break f;
               default:
                   System.out.println("Please provide the valid option");
           }
        }
    }

    public void getViewId(int id) {

            List<Task> list=updateController.viewById(id);
            System.out.println("-----------------TASK------------------");
            for(Task t: list){
                System.out.println("Task Id: "+t.getTaskId()+"\n"+"Task Description: "+t.getTaskDesc()+"\n"+
                        "Starting Date: "+t.getCurDate()+"\n"+"Due Date: "+t.getDueDate()+"\n"+
                        "Priority: "+t.getLevel()+"\n"+"Status: "+t.getStatus());
            }
            System.out.println("---------------------------------------");

    }

    public void print(){
        System.out.println("1. Change the description");
        System.out.println("2. Change the starting date");
        System.out.println("3. Change the due date");
        System.out.println("4. Change the Priority");
        System.out.println("5. Change the Status");
        System.out.println("6. exit");
        System.out.println("Choose the valid option(1-6): ");
    }
}
