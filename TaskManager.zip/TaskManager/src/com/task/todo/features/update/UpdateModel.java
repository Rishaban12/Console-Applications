package com.task.todo.features.update;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;
import com.task.todo.repo.ToDoDb;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class UpdateModel implements IControllerUpdateModel{
    private final IUpdateModelController updateController;

    public UpdateModel(UpdateController updateController){
        this.updateController=updateController;
    }

    @Override
    public List<Task> viewById(int id) {
        return ToDoDb.getInstance().viewById(id);
    }

    @Override
    public void newStatus(String status,int id) {
        ToDoDb.getInstance().newStatus(status,id);
    }

    @Override
    public void newPriority(Level l,int id) {
       ToDoDb.getInstance().newPriority(l,id);
    }

    @Override
    public void newTaskDesc(String taskDesc,int id) {
       ToDoDb.getInstance().newTaskDesc(taskDesc,id);
    }

    @Override
    public void newCurDate(LocalDate start,int id) {
      ToDoDb.getInstance().newCurDate(start,id);
    }

    @Override
    public void newDueDate(LocalDate end,int id) {
       ToDoDb.getInstance().newDueDate(end,id);
    }
}
