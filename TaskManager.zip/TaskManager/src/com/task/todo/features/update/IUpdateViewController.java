package com.task.todo.features.update;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;

import java.time.LocalDate;
import java.util.List;

public interface IUpdateViewController {
    abstract List<Task> viewById(int id);

    abstract void newTaskDesc(String taskDesc,int id);

    abstract void newCurDate(LocalDate start,int id);

    abstract void newDueDate(LocalDate end,int id);

    abstract void newPriority(Level l,int id);

    abstract void newStatus(String status,int id);
}
