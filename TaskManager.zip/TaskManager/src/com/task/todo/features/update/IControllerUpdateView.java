package com.task.todo.features.update;

public interface IControllerUpdateView {
}
