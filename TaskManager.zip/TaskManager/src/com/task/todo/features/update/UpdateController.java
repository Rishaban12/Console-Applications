package com.task.todo.features.update;

import com.task.todo.dto.Level;
import com.task.todo.dto.Task;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class UpdateController implements IUpdateViewController,IUpdateModelController{
    private final IControllerUpdateView updateView;
    private final IControllerUpdateModel updateModel;

    public UpdateController(UpdateView updateView){
        this.updateView=updateView;
        updateModel=new UpdateModel(this);
    }

    @Override
    public List<Task> viewById(int id) {
        return updateModel.viewById(id);
    }

    @Override
    public void newTaskDesc(String taskDesc,int id) {
         updateModel.newTaskDesc(taskDesc,id);
    }

    @Override
    public void newCurDate(LocalDate start,int id) {
        updateModel.newCurDate(start,id);
    }

    @Override
    public void newDueDate(LocalDate end,int id) {
      updateModel.newDueDate(end,id);
    }

    @Override
    public void newPriority(Level l,int id) {
      updateModel.newPriority(l,id);
    }

    @Override
    public void newStatus(String status,int id) {
     updateModel.newStatus(status,id);
    }
}
