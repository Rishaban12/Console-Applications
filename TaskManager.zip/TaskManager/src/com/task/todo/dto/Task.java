package com.task.todo.dto;

import java.time.LocalDate;

public class Task {
    private int taskId;
    private String taskDesc;
    private LocalDate curDate;
    private LocalDate dueDate;
    private Level level;
    private String status;

    public Task(int taskId,String taskDesc,LocalDate curDate,LocalDate dueDate,Level level,String status) {
        this.taskId = taskId;
        this.taskDesc=taskDesc;
        this.curDate=curDate;
        this.dueDate=dueDate;
        this.level=level;
        this.status=status;
    }

    public int getTaskId() {
        return taskId;
    }

    public void setTaskId(int taskId) {
        this.taskId = taskId;
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    public void setTaskDesc(String taskDesc) {
        this.taskDesc = taskDesc;
    }

    public LocalDate getCurDate() {
        return curDate;
    }

    public void setCurDate(LocalDate curDate) {
        this.curDate = curDate;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public Level getLevel() {
        return level;
    }

    public void setLevel(Level level) {
        this.level = level;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
