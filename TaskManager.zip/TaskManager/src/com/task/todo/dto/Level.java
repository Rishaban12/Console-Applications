package com.task.todo.dto;

public enum Level {
    LOW("low"),
    MEDIUM("medium"),
    HIGH("high");

    private String description;

    private Level(String description){
        this.description=description;
    }
    public String getDescription(){
        return description;
    }
}
